package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.ui.screens.*
import com.example.ui.theme.GoPayTheme
import com.example.ui.viewmodel.GoPayViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            GoPayTheme {
                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    GoPayNavigationApp()
                }
            }
        }
    }
}

@Composable
fun GoPayNavigationApp() {
    val navController = rememberNavController()
    val viewModel: GoPayViewModel = viewModel()

    NavHost(
        navController = navController,
        startDestination = "splash"
    ) {
        composable("splash") {
            SplashScreen(
                onNavigateToLogin = { navController.navigate("login") { popUpTo("splash") { inclusive = true } } },
                onNavigateToDashboard = { navController.navigate("dashboard") { popUpTo("splash") { inclusive = true } } },
                viewModel = viewModel
            )
        }

        composable("login") {
            LoginScreen(
                onNavigateToRegister = { navController.navigate("register") },
                onNavigateToDashboard = { navController.navigate("dashboard") { popUpTo("login") { inclusive = true } } },
                onNavigateToOTP = { email -> navController.navigate("otp/$email") },
                viewModel = viewModel
            )
        }

        composable("register") {
            RegisterScreen(
                onNavigateBack = { navController.popBackStack() },
                onNavigateToOTP = { email -> navController.navigate("otp/$email") },
                viewModel = viewModel
            )
        }

        composable(
            route = "otp/{email}",
            arguments = listOf(navArgument("email") { type = NavType.StringType })
        ) { backStackEntry ->
            val email = backStackEntry.arguments?.getString("email") ?: ""
            OTPScreen(
                email = email,
                onNavigateToKYC = { navController.navigate("kyc") { popUpTo("login") { inclusive = true } } },
                onNavigateToDashboard = { navController.navigate("dashboard") { popUpTo("login") { inclusive = true } } },
                viewModel = viewModel
            )
        }

        composable("kyc") {
            KYCScreen(
                onNavigateToDashboard = { navController.navigate("dashboard") { popUpTo("kyc") { inclusive = true } } },
                viewModel = viewModel
            )
        }

        composable("dashboard") {
            DashboardScreen(
                onNavigateToStripeDeposit = { navController.navigate("stripe_deposit") },
                onNavigateToCardDetails = { cardId -> navController.navigate("card_details/$cardId") },
                onNavigateToExchange = { navController.navigate("exchange") },
                onNavigateToQRCode = { navController.navigate("qrcode") },
                onNavigateToNotifications = { navController.navigate("notifications") },
                onNavigateToKYC = { navController.navigate("kyc") },
                onNavigateToLogin = { navController.navigate("login") { popUpTo("dashboard") { inclusive = true } } },
                viewModel = viewModel
            )
        }

        composable("stripe_deposit") {
            StripeDepositScreen(
                onNavigateBack = { navController.popBackStack() },
                viewModel = viewModel
            )
        }

        composable(
            route = "card_details/{cardId}",
            arguments = listOf(navArgument("cardId") { type = NavType.StringType })
        ) { backStackEntry ->
            val cardId = backStackEntry.arguments?.getString("cardId") ?: ""
            CardDetailsScreen(
                cardId = cardId,
                onNavigateBack = { navController.popBackStack() },
                viewModel = viewModel
            )
        }

        composable("exchange") {
            ExchangeScreen(
                onNavigateBack = { navController.popBackStack() },
                viewModel = viewModel
            )
        }

        composable("qrcode") {
            QRCodeScreen(
                onNavigateBack = { navController.popBackStack() },
                viewModel = viewModel
            )
        }

        composable("notifications") {
            NotificationScreen(
                onNavigateBack = { navController.popBackStack() },
                viewModel = viewModel
            )
        }
    }
}
