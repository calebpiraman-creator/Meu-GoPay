package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.CompareArrows
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.entities.CardEntity
import com.example.data.local.entities.NotificationEntity
import com.example.data.local.entities.TransactionEntity
import com.example.data.local.entities.WalletEntity
import com.example.ui.theme.*
import com.example.ui.viewmodel.GoPayViewModel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.absoluteValue

// Helper extension to format currency
fun formatCentsToCurrency(cents: Long, currency: String): String {
    val amount = cents.absoluteValue / 100.0
    val symbol = when (currency) {
        "USD" -> "$"
        "EUR" -> "€"
        "GBP" -> "£"
        "MZN" -> "MT"
        "ZAR" -> "R"
        "BRL" -> "R$"
        "AOA" -> "Kz"
        "KES" -> "Ksh"
        "NGN" -> "₦"
        else -> "$"
    }
    return "$symbol ${String.format(Locale.US, "%,.2f", amount)}"
}

// Helper color selector for CardEntity themes
fun getCardColorBrush(colorIndex: Int): Brush {
    return when (colorIndex) {
        0 -> Brush.linearGradient(colors = listOf(Color(0xFF2D3436), Color(0xFF000000))) // Elegant Dark Matte Black
        1 -> Brush.linearGradient(colors = listOf(Color(0xFF0052D4), Color(0xFF4364F7), Color(0xFF6FB1FC))) // Visa Deep Blue
        2 -> Brush.linearGradient(colors = listOf(Color(0xFF11998e), Color(0xFF38ef7d))) // Mint Green
        3 -> Brush.linearGradient(colors = listOf(Color(0xFF8E2DE2), Color(0xFF4A00E0))) // Royal Violet
        4 -> Brush.linearGradient(colors = listOf(Color(0xFFED213A), Color(0xFF93291E))) // Crimson Red
        else -> Brush.linearGradient(colors = listOf(Color(0xFF1F1F1F), Color(0xFF3A3D40)))
    }
}

// ==========================================
// 1. DASHBOARD SCREEN
// ==========================================
@Composable
fun DashboardScreen(
    onNavigateToStripeDeposit: () -> Unit,
    onNavigateToCardDetails: (String) -> Unit,
    onNavigateToExchange: () -> Unit,
    onNavigateToQRCode: () -> Unit,
    onNavigateToNotifications: () -> Unit,
    onNavigateToKYC: () -> Unit,
    onNavigateToLogin: () -> Unit,
    viewModel: GoPayViewModel
) {
    val activeUser by viewModel.activeUser.collectAsState()
    val wallets by viewModel.wallets.collectAsState()
    val cards by viewModel.cards.collectAsState()
    val transactions by viewModel.transactions.collectAsState()
    val exchangeRates by viewModel.exchangeRates.collectAsState()
    val notifications by viewModel.notifications.collectAsState()

    val unreadNotifCount = notifications.count { !it.isRead }
    val primaryWallet = wallets.find { it.currency == "USD" }
    val scope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(DeepSlateBg)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(bottom = 80.dp) // Avoid overlap with safe area
        ) {
            // --- TOP HEADER NAV BAR ---
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp, vertical = 20.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Profile Avatar Indicator
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(Brush.linearGradient(colors = listOf(Color(0xFF4A90E2), Color(0xFF2B5876)))),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = activeUser?.fullName?.take(2)?.uppercase() ?: "GP",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = "Hello, ${activeUser?.fullName?.split(" ")?.firstOrNull() ?: "User"}",
                            color = NeutralWhite,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = if (activeUser?.isKycCompleted == true) Icons.Default.Verified else Icons.Default.NewReleases,
                                contentDescription = null,
                                tint = if (activeUser?.isKycCompleted == true) ElectricGreen else CoralRed,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = if (activeUser?.isKycCompleted == true) "Verified KYC" else "Pending KYC Verification",
                                color = if (activeUser?.isKycCompleted == true) ElectricGreen else CoralRed,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }

                // Header Utility Actions
                Row {
                    IconButton(onClick = onNavigateToNotifications) {
                        Box {
                            Icon(Icons.Default.Notifications, contentDescription = "Alerts Center", tint = NeutralWhite)
                            if (unreadNotifCount > 0) {
                                Box(
                                    modifier = Modifier
                                        .size(9.dp)
                                        .align(Alignment.TopEnd)
                                        .background(CoralRed, CircleShape)
                                )
                            }
                        }
                    }

                    IconButton(onClick = { viewModel.logout { onNavigateToLogin() } }) {
                        Icon(Icons.Default.Logout, contentDescription = "Logout", tint = NeutralWhite)
                    }
                }
            }

            // --- KYC UNLOCKED WARNING BAR ---
            if (activeUser?.isKycCompleted != true) {
                Card(
                    onClick = onNavigateToKYC,
                    colors = CardDefaults.cardColors(containerColor = CoralRed.copy(alpha = 0.12f)),
                    border = BorderStroke(1.dp, CoralRed.copy(alpha = 0.3f)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 24.dp)
                        .padding(bottom = 16.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Security, contentDescription = null, tint = CoralRed)
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Complete Account Verification",
                                color = NeutralWhite,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Unlock premium Visa Virtual Prepaid features and create cards instantly.",
                                color = NeutralGray,
                                fontSize = 12.sp
                            )
                        }
                        Icon(Icons.Default.ChevronRight, contentDescription = null, tint = NeutralWhite)
                    }
                }
            }

            // --- BALANCE CARD BANNER ---
            Card(
                colors = CardDefaults.cardColors(containerColor = SlateSurface),
                border = BorderStroke(1.dp, SlateBorder),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp)
            ) {
                Column(
                    modifier = Modifier.padding(24.dp)
                ) {
                    Text(
                        text = "TOTAL WALLET BALANCE",
                        color = NeutralGray,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.5.sp
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = formatCentsToCurrency(primaryWallet?.balanceCents ?: 0L, "USD"),
                        color = NeutralWhite,
                        fontSize = 42.sp,
                        fontWeight = FontWeight.Bold
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .background(ElectricGreen, CircleShape)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Stripe Gateway linked successfully",
                            color = ElectricGreen,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // --- HORIZONTAL QUICK QUICK ACTIONS GRID ---
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                QuickActionItem(
                    icon = Icons.Default.Add,
                    label = "Add Money",
                    containerColor = ElectricPurple,
                    borderColor = Color.Transparent,
                    iconColor = Color.White,
                    onClick = onNavigateToStripeDeposit
                )
                QuickActionItem(
                    icon = Icons.AutoMirrored.Filled.CompareArrows,
                    label = "Exchange",
                    containerColor = SlateSurface,
                    borderColor = SlateBorder,
                    iconColor = NeutralWhite,
                    onClick = onNavigateToExchange
                )
                QuickActionItem(
                    icon = Icons.Default.QrCode,
                    label = "QR Pay",
                    containerColor = SlateSurface,
                    borderColor = SlateBorder,
                    iconColor = NeutralWhite,
                    onClick = onNavigateToQRCode
                )
                QuickActionItem(
                    icon = Icons.Default.AddCard,
                    label = "New Card",
                    containerColor = SlateSurface,
                    borderColor = SlateBorder,
                    iconColor = NeutralWhite,
                    onClick = {
                        if (activeUser?.isKycCompleted == true) {
                            // Issue card
                            viewModel.issueVirtualCard(activeUser?.fullName ?: "HOLDER", 50000L, "STANDARD", 3) {
                                scope.launch { snackbarHostState.showSnackbar("Visa card issued successfully!") }
                            }
                        } else {
                            onNavigateToKYC()
                        }
                    }
                )
            }

            Spacer(modifier = Modifier.height(28.dp))

            // --- MULTI-CURRENCY ACCOUNTS SLIDE PANEL ---
            Text(
                text = "Your Multi-Currency Wallets",
                color = NeutralWhite,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 24.dp)
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Horizontal Wallet Account list
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 24.dp)
            ) {
                wallets.forEach { wallet ->
                    WalletCurrencyCard(wallet)
                    Spacer(modifier = Modifier.width(12.dp))
                }
            }

            Spacer(modifier = Modifier.height(28.dp))

            // --- VISA VIRTUAL CARDS CAROUSEL ---
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "My Visa Virtual Cards",
                    color = NeutralWhite,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )

                Text(
                    text = "Manage",
                    color = ElectricPurple,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.clickable {
                        if (cards.isNotEmpty()) onNavigateToCardDetails(cards.first().id)
                    }
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            if (cards.isEmpty()) {
                // Empty Cards State
                Card(
                    onClick = {
                        if (activeUser?.isKycCompleted == true) {
                            viewModel.issueVirtualCard(activeUser?.fullName ?: "GP HOLDER", 50000L, "STANDARD", 1) {}
                        } else {
                            onNavigateToKYC()
                        }
                    },
                    colors = CardDefaults.cardColors(containerColor = SlateSurface),
                    border = BorderStroke(1.dp, SlateBorder.copy(alpha = 0.5f)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(150.dp)
                        .padding(horizontal = 24.dp)
                ) {
                    Column(
                        modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(Icons.Default.AddCard, contentDescription = null, tint = NeutralGray, modifier = Modifier.size(36.dp))
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("Issue Your First Visa Card", color = NeutralWhite, fontWeight = FontWeight.Bold)
                        Text("Secure virtual tokenized payments", color = NeutralGray, fontSize = 12.sp)
                    }
                }
            } else {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState())
                        .padding(horizontal = 24.dp)
                ) {
                    cards.forEach { card ->
                        VisaCardVisualItem(card = card, onClick = { onNavigateToCardDetails(card.id) })
                        Spacer(modifier = Modifier.width(16.dp))
                    }
                }
            }

            Spacer(modifier = Modifier.height(28.dp))

            // --- RECENT TRANSACTIONS LEDGER ---
            Text(
                text = "Recent Append-Only Ledger Logs",
                color = NeutralWhite,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 24.dp)
            )

            Spacer(modifier = Modifier.height(12.dp))

            if (transactions.isEmpty()) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = SlateSurface),
                    border = BorderStroke(1.dp, SlateBorder),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 24.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "No recorded ledger logs found. Top up to start.",
                            color = NeutralGray,
                            fontSize = 13.sp
                        )
                    }
                }
            } else {
                Card(
                    colors = CardDefaults.cardColors(containerColor = SlateSurface),
                    border = BorderStroke(1.dp, SlateBorder),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 24.dp)
                ) {
                    Column {
                        transactions.take(6).forEachIndexed { index, transaction ->
                            TransactionLedgerRow(transaction)
                            if (index < transactions.size - 1 && index < 5) {
                                HorizontalDivider(color = SlateBorder, thickness = 1.dp)
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(28.dp))

            // --- LIVE FOREX RATE MONITOR BOARD ---
            Text(
                text = "Live Foreign Exchange Tables (Forex)",
                color = NeutralWhite,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 24.dp)
            )

            Spacer(modifier = Modifier.height(12.dp))

            Card(
                colors = CardDefaults.cardColors(containerColor = SlateSurface),
                border = BorderStroke(1.dp, SlateBorder),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Forex Pair", color = NeutralGray, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        Text("Rate (to 1 USD)", color = NeutralGray, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                    HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp), color = SlateBorder)
                    
                    val rateCodes = listOf("EUR", "GBP", "MZN", "ZAR", "BRL", "AOA", "KES", "NGN")
                    rateCodes.forEach { code ->
                        val rateItem = exchangeRates.find { it.currencyCode == code }
                        val formattedRate = rateItem?.rate ?: when (code) {
                            "EUR" -> 0.92
                            "GBP" -> 0.78
                            "MZN" -> 63.8
                            "ZAR" -> 18.25
                            "BRL" -> 5.42
                            "AOA" -> 825.0
                            "KES" -> 129.0
                            "NGN" -> 1510.0
                            else -> 1.0
                        }
                        
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 6.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(18.dp)
                                        .clip(CircleShape)
                                        .background(ElectricPurple)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("USD / $code", color = NeutralWhite, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                            }
                            Text(text = String.format(Locale.US, "%,.4f", formattedRate), color = ElectricGreen, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        }
                    }
                }
            }
        }

        SnackbarHost(
            hostState = snackbarHostState,
            modifier = Modifier.align(Alignment.BottomCenter)
        )
    }
}

@Composable
fun QuickActionItem(
    icon: ImageVector,
    label: String,
    containerColor: Color = SlateSurface,
    borderColor: Color = SlateBorder,
    iconColor: Color = ElectricPurple,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.clickable { onClick() }
    ) {
        Box(
            modifier = Modifier
                .size(56.dp)
                .clip(RoundedCornerShape(16.dp))
                .background(containerColor)
                .then(
                    if (borderColor != Color.Transparent) {
                        Modifier.border(1.dp, borderColor, RoundedCornerShape(16.dp))
                    } else {
                        Modifier
                    }
                ),
            contentAlignment = Alignment.Center
        ) {
            Icon(imageVector = icon, contentDescription = label, tint = iconColor, modifier = Modifier.size(24.dp))
        }
        Spacer(modifier = Modifier.height(8.dp))
        Text(text = label, color = NeutralWhite, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
fun WalletCurrencyCard(wallet: WalletEntity) {
    Card(
        colors = CardDefaults.cardColors(containerColor = SlateSurface),
        border = BorderStroke(1.dp, SlateBorder),
        modifier = Modifier
            .width(135.dp)
            .height(85.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(12.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(20.dp)
                        .clip(CircleShape)
                        .background(ElectricPurple),
                    contentAlignment = Alignment.Center
                ) {
                    Text(wallet.currency.take(1), color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
                Spacer(modifier = Modifier.width(8.dp))
                Text(wallet.currency, color = NeutralWhite, fontSize = 14.sp, fontWeight = FontWeight.Bold)
            }
            Text(
                text = formatCentsToCurrency(wallet.balanceCents, wallet.currency),
                color = NeutralWhite,
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
fun VisaCardVisualItem(card: CardEntity, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .width(280.dp)
            .height(170.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(getCardColorBrush(card.cardColor))
            .border(1.dp, Color.White.copy(alpha = 0.15f), RoundedCornerShape(16.dp))
            .clickable { onClick() }
            .padding(20.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Card Brand Top Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "VISA PREPAID",
                        color = Color.White,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                    Text(
                        text = card.cardType,
                        color = Color.White.copy(alpha = 0.6f),
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Medium,
                        letterSpacing = 0.5.sp
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .background(
                                if (card.status == "ACTIVE") ElectricGreen else CoralRed,
                                CircleShape
                            )
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = card.status,
                        color = Color.White,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            // Card Chip
            Icon(
                imageVector = Icons.Default.QrCode,
                contentDescription = null,
                tint = GoldVisa,
                modifier = Modifier.size(30.dp)
            )

            // Card Details Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Bottom
            ) {
                Column {
                    Text(
                        text = "**** **** **** ${card.lastFour}",
                        color = Color.White,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        letterSpacing = 1.sp
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = card.cardholderName,
                        color = Color.White,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                Text(
                    text = "${String.format("%02d", card.expMonth)}/${card.expYear.toString().takeLast(2)}",
                    color = Color.White,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
            }
        }
    }
}

@Composable
fun TransactionLedgerRow(transaction: TransactionEntity) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        val isCredit = transaction.amountCents > 0
        Box(
            modifier = Modifier
                .size(40.dp)
                .background(
                    if (isCredit) ElectricGreen.copy(alpha = 0.12f) else CoralRed.copy(alpha = 0.12f),
                    CircleShape
                ),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = when (transaction.type) {
                    "DEPOSIT" -> Icons.Default.Add
                    "TRANSFER" -> Icons.AutoMirrored.Filled.CompareArrows
                    "PURCHASE" -> Icons.Default.ShoppingBag
                    else -> Icons.Default.History
                },
                contentDescription = null,
                tint = if (isCredit) ElectricGreen else CoralRed,
                modifier = Modifier.size(20.dp)
            )
        }

        Spacer(modifier = Modifier.width(14.dp))

        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = transaction.merchantName ?: transaction.description,
                color = NeutralWhite,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = SimpleDateFormat("MMM dd, yyyy HH:mm", Locale.getDefault()).format(Date(transaction.timestamp)),
                color = NeutralGray,
                fontSize = 11.sp
            )
        }

        Text(
            text = (if (isCredit) "+" else "-") + formatCentsToCurrency(transaction.amountCents.absoluteValue, transaction.currency),
            color = if (isCredit) ElectricGreen else NeutralWhite,
            fontSize = 15.sp,
            fontWeight = FontWeight.Bold
        )
    }
}

// ==========================================
// 2. STRIPE DEPOSIT (GATEWAY CHECKOUT) SCREEN
// ==========================================
@Composable
fun StripeDepositScreen(
    onNavigateBack: () -> Unit,
    viewModel: GoPayViewModel
) {
    var amountText by remember { mutableStateOf("") }
    var cardNumber by remember { mutableStateOf("") }
    var expText by remember { mutableStateOf("") }
    var cvv by remember { mutableStateOf("") }

    val scope = rememberCoroutineScope()
    val isProcessing by viewModel.isProcessing.collectAsState()
    val transactionMessage by viewModel.transactionMessage.collectAsState()
    val snackbarHostState = remember { SnackbarHostState() }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(DeepSlateBg)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp)
                .verticalScroll(rememberScrollState())
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(top = 16.dp)
            ) {
                IconButton(onClick = onNavigateBack) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = NeutralWhite)
                }
                Spacer(modifier = Modifier.width(8.dp))
                Text("Stripe Gateway TopUp", color = NeutralWhite, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Stripe banner branding
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(Brush.linearGradient(colors = listOf(ElectricPurple, Color(0xFF4364F7))))
                    .padding(20.dp)
            ) {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Stripe Direct Connect", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        Icon(Icons.Default.Shield, contentDescription = null, tint = Color.White, modifier = Modifier.size(24.dp))
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Fund your primary global USD wallet instantly using any international VISA, Mastercard, or AMEX card.",
                        color = Color.White.copy(alpha = 0.85f),
                        fontSize = 12.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Deposit Inputs
            OutlinedTextField(
                value = amountText,
                onValueChange = { amountText = it },
                label = { Text("Amount to Deposit (USD)", color = NeutralGray) },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = NeutralWhite,
                    unfocusedTextColor = NeutralWhite,
                    focusedBorderColor = ElectricPurple,
                    unfocusedBorderColor = SlateBorder,
                    focusedContainerColor = SlateSurface,
                    unfocusedContainerColor = SlateSurface
                ),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                leadingIcon = { Text("$  ", color = NeutralWhite, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 12.dp)) },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(16.dp))

            OutlinedTextField(
                value = cardNumber,
                onValueChange = { cardNumber = it },
                label = { Text("Credit / Debit Card Number", color = NeutralGray) },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = NeutralWhite,
                    unfocusedTextColor = NeutralWhite,
                    focusedBorderColor = ElectricPurple,
                    unfocusedBorderColor = SlateBorder,
                    focusedContainerColor = SlateSurface,
                    unfocusedContainerColor = SlateSurface
                ),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                leadingIcon = { Icon(Icons.Default.CreditCard, contentDescription = null, tint = NeutralGray) },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(16.dp))

            Row(modifier = Modifier.fillMaxWidth()) {
                OutlinedTextField(
                    value = expText,
                    onValueChange = { expText = it },
                    label = { Text("Expiry (MM/YY)", color = NeutralGray) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = NeutralWhite,
                        unfocusedTextColor = NeutralWhite,
                        focusedBorderColor = ElectricPurple,
                        unfocusedBorderColor = SlateBorder,
                        focusedContainerColor = SlateSurface,
                        unfocusedContainerColor = SlateSurface
                    ),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.weight(1f)
                )

                Spacer(modifier = Modifier.width(16.dp))

                OutlinedTextField(
                    value = cvv,
                    onValueChange = { if (it.length <= 4) cvv = it },
                    label = { Text("CVV Code", color = NeutralGray) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = NeutralWhite,
                        unfocusedTextColor = NeutralWhite,
                        focusedBorderColor = ElectricPurple,
                        unfocusedBorderColor = SlateBorder,
                        focusedContainerColor = SlateSurface,
                        unfocusedContainerColor = SlateSurface
                    ),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(40.dp))

            Button(
                onClick = {
                    val amtCents = (amountText.toDoubleOrNull() ?: 0.0) * 100
                    if (amtCents <= 0 || cardNumber.isEmpty() || expText.isEmpty() || cvv.isEmpty()) {
                        scope.launch { snackbarHostState.showSnackbar("All fields are mandatory to process deposit.") }
                    } else {
                        val expSplits = expText.split("/")
                        val expMonth = expSplits.firstOrNull()?.toIntOrNull() ?: 12
                        val expYear = expSplits.lastOrNull()?.toIntOrNull() ?: 2030

                        viewModel.fundWalletViaStripe(
                            amountCents = amtCents.toLong(),
                            currency = "USD",
                            cardNumber = cardNumber,
                            expMonth = expMonth,
                            expYear = expYear,
                            cvv = cvv
                        ) {
                            onNavigateBack()
                        }
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = ElectricPurple),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp)
            ) {
                Text("Process Safe TopUp via Stripe", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color.White)
            }
        }

        if (isProcessing) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.8f)),
                contentAlignment = Alignment.Center
            ) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = SlateSurface),
                    border = BorderStroke(1.dp, SlateBorder)
                ) {
                    Column(
                        modifier = Modifier.padding(32.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        CircularProgressIndicator(color = ElectricPurple)
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = transactionMessage ?: "Encrypting Stripe Session...",
                            color = NeutralWhite,
                            fontSize = 14.sp
                        )
                    }
                }
            }
        }

        SnackbarHost(
            hostState = snackbarHostState,
            modifier = Modifier.align(Alignment.BottomCenter)
        )
    }
}

// ==========================================
// 3. VISA CARD DETAILS & POS MERCHANT SIMULATOR SCREEN
// ==========================================
@Composable
fun CardDetailsScreen(
    cardId: String,
    onNavigateBack: () -> Unit,
    viewModel: GoPayViewModel
) {
    val cards by viewModel.cards.collectAsState()
    val card = cards.find { it.id == cardId }

    var decryptedPan by remember { mutableStateOf("•••• •••• •••• ••••") }
    var decryptedCvv by remember { mutableStateOf("•••") }
    var isRevealed by remember { mutableStateOf(false) }
    var secureRevealPrompt by remember { mutableStateOf(false) }
    var verifyPasscode by remember { mutableStateOf("") }

    // POS Simulator Widgets
    var showPOSWidget by remember { mutableStateOf(false) }
    var posAmountText by remember { mutableStateOf("15.99") }
    var posMerchant by remember { mutableStateOf("Netflix Inc.") }

    val isProcessing by viewModel.isProcessing.collectAsState()
    val transactionMessage by viewModel.transactionMessage.collectAsState()
    val scope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }
    val clipboardManager = LocalClipboardManager.current

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(DeepSlateBg)
    ) {
        if (card == null) {
            Column(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("Card details not found or closed.", color = NeutralGray)
                Spacer(modifier = Modifier.height(12.dp))
                Button(onClick = onNavigateBack) { Text("Go Back") }
            }
        } else {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(24.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(top = 16.dp)
                ) {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = NeutralWhite)
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Visa Card Settings", color = NeutralWhite, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                }

                Spacer(modifier = Modifier.height(24.dp))

                // Interactive Physical-looking card display
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(200.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(getCardColorBrush(card.cardColor))
                        .border(1.dp, Color.White.copy(alpha = 0.15f), RoundedCornerShape(16.dp))
                        .padding(24.dp)
                ) {
                    Column(
                        modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text("VISA PREPAID", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp, letterSpacing = 1.5.sp)
                                Text(card.cardType, color = Color.White.copy(alpha = 0.6f), fontSize = 11.sp)
                            }
                            Text(card.status, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }

                        // Decrypted or Masked PAN display
                        Text(
                            text = if (isRevealed) decryptedPan.chunked(4).joinToString(" ") else "**** **** **** ${card.lastFour}",
                            color = Color.White,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            textAlign = TextAlign.Center,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    if (!isRevealed) {
                                        secureRevealPrompt = true
                                    } else {
                                        isRevealed = false
                                    }
                                }
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.Bottom
                        ) {
                            Column {
                                Text(card.cardholderName, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                                Spacer(modifier = Modifier.height(4.dp))
                                Text("CVV: ${if (isRevealed) decryptedCvv else "•••"}", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                            }

                            Text(
                                text = "EXP: ${String.format("%02d", card.expMonth)}/${card.expYear.toString().takeLast(2)}",
                                color = Color.White,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                // REVEAL CARD SECURITY BUTTON
                Button(
                    onClick = {
                        if (!isRevealed) {
                            secureRevealPrompt = true
                        } else {
                            isRevealed = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = if (isRevealed) CoralRed else ElectricPurple),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(imageVector = if (isRevealed) Icons.Default.VisibilityOff else Icons.Default.Visibility, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(if (isRevealed) "Hide Sensitive Credentials" else "Show Sensitive Credentials (PCI Sec)")
                }

                Spacer(modifier = Modifier.height(28.dp))

                // CARD MANAGEMENT OPTIONS
                Text("Card Controls", color = NeutralWhite, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                
                Spacer(modifier = Modifier.height(12.dp))

                // Freeze Toggler Row
                Card(
                    colors = CardDefaults.cardColors(containerColor = SlateSurface),
                    border = BorderStroke(1.dp, SlateBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(40.dp)
                                    .background(ElectricPurple.copy(alpha = 0.12f), CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.AcUnit, contentDescription = null, tint = ElectricPurple)
                            }
                            Spacer(modifier = Modifier.width(14.dp))
                            Column {
                                Text("Freeze Card Temporarily", color = NeutralWhite, fontWeight = FontWeight.Bold)
                                Text("Locks transactions on this Visa card", color = NeutralGray, fontSize = 11.sp)
                            }
                        }

                        Switch(
                            checked = (card.status == "FROZEN"),
                            onCheckedChange = { viewModel.toggleCardFreeze(card.id) },
                            colors = SwitchDefaults.colors(checkedThumbColor = ElectricPurple)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Terminate Toggler Row
                Card(
                    onClick = { viewModel.terminateCard(card.id); onNavigateBack() },
                    colors = CardDefaults.cardColors(containerColor = SlateSurface),
                    border = BorderStroke(1.dp, SlateBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .background(CoralRed.copy(alpha = 0.12f), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.Delete, contentDescription = null, tint = CoralRed)
                        }
                        Spacer(modifier = Modifier.width(14.dp))
                        Column {
                            Text("Permanent Deactivation", color = CoralRed, fontWeight = FontWeight.Bold)
                            Text("Destroy and terminate card HSM profile permanently", color = NeutralGray, fontSize = 11.sp)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(28.dp))

                // --- POS TERMINAL SIMULATION FOR TESTING PURCHASE ---
                Card(
                    colors = CardDefaults.cardColors(containerColor = SlateSurface),
                    border = BorderStroke(1.dp, ElectricPurple.copy(alpha = 0.4f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(20.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Visa Point-of-Sale (POS) Sandbox", color = NeutralWhite, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                            IconButton(onClick = { showPOSWidget = !showPOSWidget }) {
                                Icon(imageVector = if (showPOSWidget) Icons.Default.ExpandLess else Icons.Default.ExpandMore, contentDescription = null, tint = ElectricPurple)
                            }
                        }
                        
                        Text("Simulate shopping and verify local append-only ledger entries.", color = NeutralGray, fontSize = 12.sp)

                        if (showPOSWidget) {
                            Spacer(modifier = Modifier.height(16.dp))

                            OutlinedTextField(
                                value = posMerchant,
                                onValueChange = { posMerchant = it },
                                label = { Text("Merchant / Store Name", color = NeutralGray) },
                                colors = OutlinedTextFieldDefaults.colors(focusedTextColor = NeutralWhite, unfocusedTextColor = NeutralWhite, focusedContainerColor = DeepSlateBg, unfocusedContainerColor = DeepSlateBg),
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )

                            Spacer(modifier = Modifier.height(10.dp))

                            OutlinedTextField(
                                value = posAmountText,
                                onValueChange = { posAmountText = it },
                                label = { Text("Purchase Amount (USD)", color = NeutralGray) },
                                colors = OutlinedTextFieldDefaults.colors(focusedTextColor = NeutralWhite, unfocusedTextColor = NeutralWhite, focusedContainerColor = DeepSlateBg, unfocusedContainerColor = DeepSlateBg),
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )

                            Spacer(modifier = Modifier.height(16.dp))

                            Button(
                                onClick = {
                                    val amtDouble = posAmountText.toDoubleOrNull() ?: 0.0
                                    val cents = (amtDouble * 100).toLong()
                                    if (cents <= 0) {
                                        scope.launch { snackbarHostState.showSnackbar("Specify a positive purchase amount.") }
                                    } else {
                                        viewModel.simulateMerchantPurchase(card.cardToken, cents, posMerchant) { success, msg ->
                                            scope.launch { snackbarHostState.showSnackbar(msg) }
                                        }
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = ElectricGreen),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Icon(Icons.Default.ShoppingCart, contentDescription = null, tint = Color.White)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Execute Mock Swipe POS", color = Color.White)
                            }
                        }
                    }
                }
            }
        }

        // --- SECONDARY PIN SECURE OVERLAY PROMPT ---
        if (secureRevealPrompt) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.85f)),
                contentAlignment = Alignment.Center
            ) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = SlateSurface),
                    border = BorderStroke(1.dp, SlateBorder),
                    modifier = Modifier
                        .fillMaxWidth(0.9f)
                        .padding(16.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(Icons.Default.Fingerprint, contentDescription = null, tint = ElectricPurple, modifier = Modifier.size(56.dp))
                        Spacer(modifier = Modifier.height(12.dp))
                        Text("2FA Passcode Verification", color = NeutralWhite, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        Text("Decryption triggers PCI HSM key mapping.", color = NeutralGray, fontSize = 12.sp, textAlign = TextAlign.Center)

                        Spacer(modifier = Modifier.height(16.dp))

                        OutlinedTextField(
                            value = verifyPasscode,
                            onValueChange = { verifyPasscode = it },
                            label = { Text("Enter security PIN", color = NeutralGray) },
                            visualTransformation = PasswordVisualTransformation(),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                            colors = OutlinedTextFieldDefaults.colors(focusedTextColor = NeutralWhite, unfocusedTextColor = NeutralWhite),
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )

                        Spacer(modifier = Modifier.height(20.dp))

                        Row(modifier = Modifier.fillMaxWidth()) {
                            OutlinedButton(
                                onClick = { secureRevealPrompt = false; verifyPasscode = "" },
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("Cancel", color = NeutralWhite)
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Button(
                                onClick = {
                                    if (verifyPasscode.isNotEmpty()) {
                                        scope.launch {
                                            if (card != null) {
                                                val creds = viewModel.revealCardDetails(card.cardToken)
                                                decryptedPan = creds.pan
                                                decryptedCvv = creds.cvv
                                                isRevealed = true
                                                secureRevealPrompt = false
                                                verifyPasscode = ""
                                            }
                                        }
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = ElectricPurple),
                                modifier = Modifier.weight(1.5f)
                            ) {
                                Text("Decrypt Credentials")
                            }
                        }
                    }
                }
            }
        }

        if (isProcessing) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.8f)),
                contentAlignment = Alignment.Center
            ) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = SlateSurface),
                    border = BorderStroke(1.dp, SlateBorder)
                ) {
                    Column(
                        modifier = Modifier.padding(32.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        CircularProgressIndicator(color = ElectricPurple)
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = transactionMessage ?: "Validating...",
                            color = NeutralWhite,
                            fontSize = 14.sp
                        )
                    }
                }
            }
        }

        SnackbarHost(
            hostState = snackbarHostState,
            modifier = Modifier.align(Alignment.BottomCenter)
        )
    }
}

// ==========================================
// 4. CURRENCY EXCHANGE / CONVERTER SCREEN
// ==========================================
@Composable
fun ExchangeScreen(
    onNavigateBack: () -> Unit,
    viewModel: GoPayViewModel
) {
    var sourceAmtText by remember { mutableStateOf("") }
    var sourceCurrency by remember { mutableStateOf("USD") }
    var destCurrency by remember { mutableStateOf("EUR") }
    var dropdownSourceExpanded by remember { mutableStateOf(false) }
    var dropdownDestExpanded by remember { mutableStateOf(false) }

    val wallets by viewModel.wallets.collectAsState()
    val exchangeRates by viewModel.exchangeRates.collectAsState()
    val isProcessing by viewModel.isProcessing.collectAsState()
    val transactionMessage by viewModel.transactionMessage.collectAsState()

    val currencyCodes = listOf("USD", "EUR", "GBP", "MZN", "ZAR", "BRL", "AOA", "KES", "NGN")
    val scope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(DeepSlateBg)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp)
                .verticalScroll(rememberScrollState())
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(top = 16.dp)
            ) {
                IconButton(onClick = onNavigateBack) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = NeutralWhite)
                }
                Spacer(modifier = Modifier.width(8.dp))
                Text("Inter-Wallet Exchange", color = NeutralWhite, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Conversion Panel
            Card(
                colors = CardDefaults.cardColors(containerColor = SlateSurface),
                border = BorderStroke(1.dp, SlateBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text("FROM WALLET", color = NeutralGray, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = sourceAmtText,
                            onValueChange = { sourceAmtText = it },
                            placeholder = { Text("0.00", color = NeutralGray) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            colors = OutlinedTextFieldDefaults.colors(focusedTextColor = NeutralWhite, unfocusedTextColor = NeutralWhite),
                            modifier = Modifier.weight(1.5f)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Box(modifier = Modifier.weight(1f)) {
                            Button(
                                onClick = { dropdownSourceExpanded = true },
                                colors = ButtonDefaults.buttonColors(containerColor = SlateBorder),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text(sourceCurrency, color = NeutralWhite)
                                Icon(Icons.Default.ArrowDropDown, contentDescription = null, tint = NeutralWhite)
                            }
                            DropdownMenu(
                                expanded = dropdownSourceExpanded,
                                onDismissRequest = { dropdownSourceExpanded = false },
                                modifier = Modifier.background(SlateSurface)
                            ) {
                                currencyCodes.forEach { code ->
                                    DropdownMenuItem(
                                        text = { Text(code, color = NeutralWhite) },
                                        onClick = { sourceCurrency = code; dropdownSourceExpanded = false }
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    val walletItem = wallets.find { it.currency == sourceCurrency }
                    Text(
                        text = "Wallet Balance: ${formatCentsToCurrency(walletItem?.balanceCents ?: 0L, sourceCurrency)}",
                        color = NeutralGray,
                        fontSize = 12.sp
                    )

                    Spacer(modifier = Modifier.height(20.dp))

                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.CompareArrows,
                        contentDescription = null,
                        tint = ElectricPurple,
                        modifier = Modifier
                            .align(Alignment.CenterHorizontally)
                            .size(32.dp)
                    )

                    Spacer(modifier = Modifier.height(20.dp))

                    Text("TO WALLET (TARGET)", color = NeutralGray, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Calculate converted rate for interactive preview
                        val sourceRate = exchangeRates.find { it.currencyCode == sourceCurrency }?.rate ?: 1.0
                        val destRate = exchangeRates.find { it.currencyCode == destCurrency }?.rate ?: 1.0
                        val rawAmt = sourceAmtText.toDoubleOrNull() ?: 0.0
                        val conversionRatio = destRate / sourceRate
                        val previewConverted = rawAmt * conversionRatio

                        OutlinedTextField(
                            value = if (rawAmt > 0) String.format(Locale.US, "%,.2f", previewConverted) else "",
                            onValueChange = {},
                            readOnly = true,
                            colors = OutlinedTextFieldDefaults.colors(focusedTextColor = NeutralWhite, unfocusedTextColor = NeutralWhite),
                            modifier = Modifier.weight(1.5f)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Box(modifier = Modifier.weight(1f)) {
                            Button(
                                onClick = { dropdownDestExpanded = true },
                                colors = ButtonDefaults.buttonColors(containerColor = SlateBorder),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text(destCurrency, color = NeutralWhite)
                                Icon(Icons.Default.ArrowDropDown, contentDescription = null, tint = NeutralWhite)
                            }
                            DropdownMenu(
                                expanded = dropdownDestExpanded,
                                onDismissRequest = { dropdownDestExpanded = false },
                                modifier = Modifier.background(SlateSurface)
                            ) {
                                currencyCodes.forEach { code ->
                                    DropdownMenuItem(
                                        text = { Text(code, color = NeutralWhite) },
                                        onClick = { destCurrency = code; dropdownDestExpanded = false }
                                    )
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(40.dp))

            Button(
                onClick = {
                    val rawDouble = sourceAmtText.toDoubleOrNull() ?: 0.0
                    val cents = (rawDouble * 100).toLong()
                    if (cents <= 0) {
                        scope.launch { snackbarHostState.showSnackbar("Please enter a positive amount.") }
                    } else if (sourceCurrency == destCurrency) {
                        scope.launch { snackbarHostState.showSnackbar("Cannot exchange between identical currencies.") }
                    } else {
                        viewModel.convertCurrency(
                            fromCurrency = sourceCurrency,
                            toCurrency = destCurrency,
                            amountCents = cents,
                            onSuccess = { onNavigateBack() },
                            onFailure = { err -> scope.launch { snackbarHostState.showSnackbar(err) } }
                        )
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = ElectricPurple),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp)
            ) {
                Text("Confirm Swap Ledger Action", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color.White)
            }
        }

        if (isProcessing) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.8f)),
                contentAlignment = Alignment.Center
            ) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = SlateSurface),
                    border = BorderStroke(1.dp, SlateBorder)
                ) {
                    Column(
                        modifier = Modifier.padding(32.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        CircularProgressIndicator(color = ElectricPurple)
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = transactionMessage ?: "Executing Forex Ledger Entry...",
                            color = NeutralWhite,
                            fontSize = 14.sp
                        )
                    }
                }
            }
        }

        SnackbarHost(
            hostState = snackbarHostState,
            modifier = Modifier.align(Alignment.BottomCenter)
        )
    }
}

// ==========================================
// 5. QR CODE PAY SCANNER / RECEIPT GENERATOR SCREEN
// ==========================================
@Composable
fun QRCodeScreen(
    onNavigateBack: () -> Unit,
    viewModel: GoPayViewModel
) {
    var amountText by remember { mutableStateOf("") }
    var scanSimulated by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(DeepSlateBg)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 16.dp)
            ) {
                IconButton(onClick = onNavigateBack) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = NeutralWhite)
                }
                Spacer(modifier = Modifier.width(8.dp))
                Text("QR Code Payments", color = NeutralWhite, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            }

            Spacer(modifier = Modifier.height(24.dp))

            Text("My Payment Address", color = NeutralWhite, fontSize = 24.sp, fontWeight = FontWeight.Bold)
            Text("Show this code to anyone to receive USD, EUR, or GBP instantly.", color = NeutralGray, fontSize = 13.sp, textAlign = TextAlign.Center)

            Spacer(modifier = Modifier.height(30.dp))

            // Beautiful simulated QR Code box
            Box(
                modifier = Modifier
                    .size(240.dp)
                    .clip(RoundedCornerShape(24.dp))
                    .background(Color.White)
                    .border(3.dp, ElectricPurple, RoundedCornerShape(24.dp))
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.QrCode,
                    contentDescription = null,
                    tint = Color.Black,
                    modifier = Modifier.fillMaxSize()
                )
            }

            Spacer(modifier = Modifier.height(40.dp))

            Text("Scan to Pay", color = NeutralWhite, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(8.dp))

            OutlinedTextField(
                value = amountText,
                onValueChange = { amountText = it },
                label = { Text("Amount to Pay (USD)", color = NeutralGray) },
                colors = OutlinedTextFieldDefaults.colors(focusedTextColor = NeutralWhite, unfocusedTextColor = NeutralWhite),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(20.dp))

            Button(
                onClick = {
                    val amtDouble = amountText.toDoubleOrNull() ?: 0.0
                    if (amtDouble <= 0) {
                        scope.launch { snackbarHostState.showSnackbar("Please enter a valid amount.") }
                    } else {
                        scanSimulated = true
                        scope.launch {
                            delay(2000)
                            scanSimulated = false
                            snackbarHostState.showSnackbar("QR Payment of $${String.format("%.2f", amtDouble)} sent successfully!")
                            onNavigateBack()
                        }
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = ElectricPurple),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp)
            ) {
                Icon(Icons.Default.QrCodeScanner, contentDescription = null, tint = Color.White)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Simulate Camera QR Scan", color = Color.White)
            }
        }

        if (scanSimulated) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.8f)),
                contentAlignment = Alignment.Center
            ) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = SlateSurface),
                    border = BorderStroke(1.dp, SlateBorder)
                ) {
                    Column(
                        modifier = Modifier.padding(32.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        CircularProgressIndicator(color = ElectricPurple)
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = "Matching payment address securely...",
                            color = NeutralWhite,
                            fontSize = 14.sp
                        )
                    }
                }
            }
        }

        SnackbarHost(
            hostState = snackbarHostState,
            modifier = Modifier.align(Alignment.BottomCenter)
        )
    }
}

// ==========================================
// 6. NOTIFICATION CENTER SCREEN
// ==========================================
@Composable
fun NotificationScreen(
    onNavigateBack: () -> Unit,
    viewModel: GoPayViewModel
) {
    val notifications by viewModel.notifications.collectAsState()

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(DeepSlateBg)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(top = 16.dp)
            ) {
                IconButton(onClick = onNavigateBack) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = NeutralWhite)
                }
                Spacer(modifier = Modifier.width(8.dp))
                Text("Security & Activity Logs", color = NeutralWhite, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            }

            Spacer(modifier = Modifier.height(24.dp))

            if (notifications.isEmpty()) {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Text("No push alerts or activity logs found.", color = NeutralGray)
                }
            } else {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(notifications) { notif ->
                        NotificationCardRow(notif = notif, onMarkRead = { viewModel.markNotificationAsRead(notif.id) })
                    }
                }
            }
        }
    }
}

@Composable
fun NotificationCardRow(notif: NotificationEntity, onMarkRead: () -> Unit) {
    Card(
        colors = CardDefaults.cardColors(
            containerColor = if (notif.isRead) SlateSurface else SlateSurface.copy(alpha = 0.85f)
        ),
        border = BorderStroke(1.dp, if (notif.isRead) SlateBorder else ElectricPurple.copy(alpha = 0.5f)),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onMarkRead() }
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .background(
                        when (notif.type) {
                            "SECURITY" -> CoralRed.copy(alpha = 0.12f)
                            "TRANSACTION" -> ElectricGreen.copy(alpha = 0.12f)
                            else -> ElectricPurple.copy(alpha = 0.12f)
                        },
                        CircleShape
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = when (notif.type) {
                        "SECURITY" -> Icons.Default.Security
                        "TRANSACTION" -> Icons.Default.Add
                        else -> Icons.Default.Info
                    },
                    contentDescription = null,
                    tint = when (notif.type) {
                        "SECURITY" -> CoralRed
                        "TRANSACTION" -> ElectricGreen
                        else -> ElectricPurple
                    },
                    modifier = Modifier.size(18.dp)
                )
            }

            Spacer(modifier = Modifier.width(14.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = notif.title,
                    color = NeutralWhite,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = notif.body,
                    color = NeutralGray,
                    fontSize = 12.sp
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = SimpleDateFormat("MMM dd, yyyy HH:mm", Locale.getDefault()).format(Date(notif.timestamp)),
                    color = NeutralGray.copy(alpha = 0.6f),
                    fontSize = 10.sp
                )
            }
        }
    }
}
