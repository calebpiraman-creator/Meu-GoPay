package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val GoPayDarkColorScheme = darkColorScheme(
    primary = ElectricPurple,
    onPrimary = Color.White,
    secondary = VisaBlue,
    onSecondary = Color.White,
    tertiary = GoldVisa,
    background = DeepSlateBg,
    onBackground = NeutralWhite,
    surface = SlateSurface,
    onSurface = NeutralWhite,
    surfaceVariant = SlateBorder,
    onSurfaceVariant = NeutralGray,
    error = CoralRed,
    onError = Color.White
)

private val GoPayLightColorScheme = lightColorScheme(
    primary = ElectricPurple,
    onPrimary = Color.White,
    secondary = VisaBlue,
    onSecondary = Color.White,
    tertiary = GoldVisa,
    background = Color(0xFFF7F8FA),
    onBackground = Color(0xFF14161E),
    surface = Color.White,
    onSurface = Color(0xFF14161E),
    surfaceVariant = Color(0xFFE5E7EB),
    onSurfaceVariant = Color(0xFF6B7280),
    error = CoralRed,
    onError = Color.White
)

@Composable
fun GoPayTheme(
    darkTheme: Boolean = true, // Force premium dark theme by default
    dynamicColor: Boolean = false, // Use our handcrafted colors instead of system colors
    content: @Composable () -> Unit
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> GoPayDarkColorScheme
        else -> GoPayLightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
