package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.entities.UserEntity
import com.example.ui.theme.*
import com.example.ui.viewmodel.GoPayViewModel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

// ==========================================
// 1. SPLASH SCREEN
// ==========================================
@Composable
fun SplashScreen(onNavigateToLogin: () -> Unit, onNavigateToDashboard: () -> Unit, viewModel: GoPayViewModel) {
    val activeUser by viewModel.activeUser.collectAsState()
    val scope = rememberCoroutineScope()
    var startAnimation by remember { mutableStateOf(false) }

    val alphaAnim = animateFloatAsState(
        targetValue = if (startAnimation) 1f else 0f,
        animationSpec = tween(durationMillis = 1500, easing = FastOutSlowInEasing),
        label = "Alpha"
    )

    val scaleAnim = animateFloatAsState(
        targetValue = if (startAnimation) 1.1f else 0.8f,
        animationSpec = tween(durationMillis = 1500, easing = FastOutSlowInEasing),
        label = "Scale"
    )

    LaunchedEffect(key1 = true) {
        startAnimation = true
        delay(2200) // Beautiful cinematic duration
        scope.launch {
            if (activeUser != null && activeUser?.isLoggedIn == true) {
                onNavigateToDashboard()
            } else {
                onNavigateToLogin()
            }
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(DeepSlateBg, Color(0xFF140D33), DeepSlateBg)
                )
            ),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(24.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(100.dp * scaleAnim.value)
                    .clip(CircleShape)
                    .background(
                        Brush.linearGradient(
                            colors = listOf(ElectricPurple, Color(0xFF0057B8))
                        )
                    )
                    .border(2.dp, GoldVisa.copy(alpha = alphaAnim.value), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.CreditCard,
                    contentDescription = "GoPay Logo Icon",
                    tint = Color.White,
                    modifier = Modifier.size(50.dp)
                )
            }

            Spacer(modifier = Modifier.height(24.dp))

            Text(
                text = "GoPay",
                color = NeutralWhite,
                fontSize = 42.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 2.sp,
                fontFamily = FontFamily.SansSerif,
                modifier = Modifier.testTag("app_logo_title")
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "Visa Virtual Prepaid Platform",
                color = NeutralGray,
                fontSize = 14.sp,
                letterSpacing = 1.sp,
                fontWeight = FontWeight.Medium
            )
        }

        CircularProgressIndicator(
            color = ElectricPurple,
            strokeWidth = 3.dp,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 60.dp)
                .size(36.dp)
        )
    }
}

// ==========================================
// 2. LOGIN SCREEN
// ==========================================
@Composable
fun LoginScreen(
    onNavigateToRegister: () -> Unit,
    onNavigateToDashboard: () -> Unit,
    onNavigateToOTP: (String) -> Unit,
    viewModel: GoPayViewModel
) {
    var email by remember { mutableStateOf("") }
    var pinCode by remember { mutableStateOf("") }
    val isProcessing by viewModel.isProcessing.collectAsState()
    val transactionMessage by viewModel.transactionMessage.collectAsState()
    val activeUser by viewModel.activeUser.collectAsState()
    val scope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(DeepSlateBg)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(modifier = Modifier.height(50.dp))

            // Branding Top
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                Icon(
                    imageVector = Icons.Default.CreditCard,
                    contentDescription = "Visa",
                    tint = ElectricPurple,
                    modifier = Modifier.size(28.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "GoPay",
                    color = NeutralWhite,
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = "Welcome Back",
                color = NeutralWhite,
                fontSize = 32.sp,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center
            )

            Text(
                text = "Enter your security details to access your secure Visa vault",
                color = NeutralGray,
                fontSize = 14.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
            )

            Spacer(modifier = Modifier.height(40.dp))

            // Text Inputs
            OutlinedTextField(
                value = email,
                onValueChange = { email = it },
                label = { Text("Email Address", color = NeutralGray) },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = NeutralWhite,
                    unfocusedTextColor = NeutralWhite,
                    focusedBorderColor = ElectricPurple,
                    unfocusedBorderColor = SlateBorder,
                    focusedContainerColor = SlateSurface,
                    unfocusedContainerColor = SlateSurface
                ),
                leadingIcon = { Icon(Icons.Default.Email, contentDescription = null, tint = NeutralGray) },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("username_input")
            )

            Spacer(modifier = Modifier.height(16.dp))

            OutlinedTextField(
                value = pinCode,
                onValueChange = { if (it.length <= 6) pinCode = it },
                label = { Text("Security passcode / PIN", color = NeutralGray) },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = NeutralWhite,
                    unfocusedTextColor = NeutralWhite,
                    focusedBorderColor = ElectricPurple,
                    unfocusedBorderColor = SlateBorder,
                    focusedContainerColor = SlateSurface,
                    unfocusedContainerColor = SlateSurface
                ),
                leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null, tint = NeutralGray) },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                visualTransformation = PasswordVisualTransformation(),
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(24.dp))

            Button(
                onClick = {
                    if (email.isEmpty() || pinCode.isEmpty()) {
                        scope.launch {
                            snackbarHostState.showSnackbar("Please fill in all security fields.")
                        }
                    } else {
                        // Navigate to OTP check for secure 2FA
                        onNavigateToOTP(email)
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = ElectricPurple),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp)
                    .testTag("login_button")
            ) {
                Text(
                    text = "Authenticate Securely",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = Color.White
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            Row(
                modifier = Modifier.clickable { onNavigateToRegister() },
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Don't have an account? ",
                    color = NeutralGray,
                    fontSize = 14.sp
                )
                Text(
                    text = "Register Global Wallet",
                    color = ElectricPurple,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }

            Spacer(modifier = Modifier.weight(1f))

            // Bottom Trust badges
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center,
                modifier = Modifier.padding(bottom = 12.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Shield,
                    contentDescription = null,
                    tint = ElectricGreen,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "PCI DSS Compliant | Secure Visa Tokenization",
                    color = NeutralGray,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Medium
                )
            }
        }

        if (isProcessing) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.75f)),
                contentAlignment = Alignment.Center
            ) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = SlateSurface),
                    border = BorderStroke(1.dp, SlateBorder)
                ) {
                    Column(
                        modifier = Modifier.padding(32.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        CircularProgressIndicator(color = ElectricPurple)
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = transactionMessage ?: "Securing connection...",
                            color = NeutralWhite,
                            fontSize = 14.sp
                        )
                    }
                }
            }
        }

        SnackbarHost(
            hostState = snackbarHostState,
            modifier = Modifier.align(Alignment.BottomCenter)
        )
    }
}

// ==========================================
// 3. REGISTER SCREEN
// ==========================================
@Composable
fun RegisterScreen(
    onNavigateBack: () -> Unit,
    onNavigateToOTP: (String) -> Unit,
    viewModel: GoPayViewModel
) {
    var fullName by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var selectedCountry by remember { mutableStateOf("United States") }
    var expandedCountries by remember { mutableStateOf(false) }

    val countriesList = listOf(
        "United States", "Brazil", "Mozambique", "Angola", "Portugal", "Spain",
        "United Kingdom", "South Africa", "Nigeria", "Kenya", "France"
    )

    val scope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }
    val isProcessing by viewModel.isProcessing.collectAsState()
    val transactionMessage by viewModel.transactionMessage.collectAsState()

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(DeepSlateBg)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(top = 16.dp)
            ) {
                IconButton(onClick = onNavigateBack) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = NeutralWhite
                    )
                }
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Global Registration",
                    color = NeutralWhite,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = "Open Multi-Currency Wallet",
                color = NeutralWhite,
                fontSize = 28.sp,
                fontWeight = FontWeight.Bold
            )

            Text(
                text = "Sign up from anywhere globally. The core currency is USD with automated conversions.",
                color = NeutralGray,
                fontSize = 14.sp,
                modifier = Modifier.padding(vertical = 4.dp)
            )

            Spacer(modifier = Modifier.height(24.dp))

            // Inputs
            OutlinedTextField(
                value = fullName,
                onValueChange = { fullName = it },
                label = { Text("Full Legal Name", color = NeutralGray) },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = NeutralWhite,
                    unfocusedTextColor = NeutralWhite,
                    focusedBorderColor = ElectricPurple,
                    unfocusedBorderColor = SlateBorder,
                    focusedContainerColor = SlateSurface,
                    unfocusedContainerColor = SlateSurface
                ),
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(12.dp))

            OutlinedTextField(
                value = email,
                onValueChange = { email = it },
                label = { Text("Email Address", color = NeutralGray) },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = NeutralWhite,
                    unfocusedTextColor = NeutralWhite,
                    focusedBorderColor = ElectricPurple,
                    unfocusedBorderColor = SlateBorder,
                    focusedContainerColor = SlateSurface,
                    unfocusedContainerColor = SlateSurface
                ),
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(12.dp))

            OutlinedTextField(
                value = phone,
                onValueChange = { phone = it },
                label = { Text("Phone Number (E.164: +123...)", color = NeutralGray) },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = NeutralWhite,
                    unfocusedTextColor = NeutralWhite,
                    focusedBorderColor = ElectricPurple,
                    unfocusedBorderColor = SlateBorder,
                    focusedContainerColor = SlateSurface,
                    unfocusedContainerColor = SlateSurface
                ),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Country Selector Dropdown
            Box(modifier = Modifier.fillMaxWidth()) {
                OutlinedTextField(
                    value = selectedCountry,
                    onValueChange = {},
                    readOnly = true,
                    label = { Text("Country of Residence", color = NeutralGray) },
                    trailingIcon = {
                        Icon(
                            imageVector = Icons.Default.ArrowDropDown,
                            contentDescription = null,
                            tint = NeutralWhite,
                            modifier = Modifier.clickable { expandedCountries = true }
                        )
                    },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = NeutralWhite,
                        unfocusedTextColor = NeutralWhite,
                        focusedBorderColor = ElectricPurple,
                        unfocusedBorderColor = SlateBorder,
                        focusedContainerColor = SlateSurface,
                        unfocusedContainerColor = SlateSurface
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { expandedCountries = true }
                )

                DropdownMenu(
                    expanded = expandedCountries,
                    onDismissRequest = { expandedCountries = false },
                    modifier = Modifier
                        .fillMaxWidth(0.85f)
                        .background(SlateSurface)
                        .border(1.dp, SlateBorder)
                ) {
                    countriesList.forEach { country ->
                        DropdownMenuItem(
                            text = { Text(country, color = NeutralWhite) },
                            onClick = {
                                selectedCountry = country
                                expandedCountries = false
                            }
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(28.dp))

            Button(
                onClick = {
                    if (fullName.isEmpty() || email.isEmpty() || phone.isEmpty()) {
                        scope.launch {
                            snackbarHostState.showSnackbar("All fields are mandatory.")
                        }
                    } else {
                        // Register local mock user state, then prompt OTP
                        viewModel.register(fullName, email, phone, selectedCountry) {
                            onNavigateToOTP(email)
                        }
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = ElectricPurple),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp)
            ) {
                Text(
                    text = "Initiate Onboarding",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = Color.White
                )
            }
        }

        if (isProcessing) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.75f)),
                contentAlignment = Alignment.Center
            ) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = SlateSurface),
                    border = BorderStroke(1.dp, SlateBorder)
                ) {
                    Column(
                        modifier = Modifier.padding(32.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        CircularProgressIndicator(color = ElectricPurple)
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = transactionMessage ?: "Registering account...",
                            color = NeutralWhite,
                            fontSize = 14.sp
                        )
                    }
                }
            }
        }

        SnackbarHost(
            hostState = snackbarHostState,
            modifier = Modifier.align(Alignment.BottomCenter)
        )
    }
}

// ==========================================
// 4. OTP SECURITY SCREEN
// ==========================================
@Composable
fun OTPScreen(
    email: String,
    onNavigateToKYC: () -> Unit,
    onNavigateToDashboard: () -> Unit,
    viewModel: GoPayViewModel
) {
    var code1 by remember { mutableStateOf("") }
    var code2 by remember { mutableStateOf("") }
    var code3 by remember { mutableStateOf("") }
    var code4 by remember { mutableStateOf("") }

    val activeUser by viewModel.activeUser.collectAsState()
    val scope = rememberCoroutineScope()
    val isProcessing by viewModel.isProcessing.collectAsState()

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(DeepSlateBg)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(modifier = Modifier.height(40.dp))

            Box(
                modifier = Modifier
                    .size(80.dp)
                    .background(ElectricPurple.copy(alpha = 0.15f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Sms,
                    contentDescription = null,
                    tint = ElectricPurple,
                    modifier = Modifier.size(36.dp)
                )
            }

            Spacer(modifier = Modifier.height(24.dp))

            Text(
                text = "Two-Factor Verification",
                color = NeutralWhite,
                fontSize = 28.sp,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "We sent a 4-digit security PIN to your phone and email ($email). Enter it below.",
                color = NeutralGray,
                fontSize = 14.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(horizontal = 16.dp)
            )

            Spacer(modifier = Modifier.height(40.dp))

            // Row of Digit Boxes
            Row(
                horizontalArrangement = Arrangement.SpaceEvenly,
                modifier = Modifier.fillMaxWidth(0.85f)
            ) {
                OtpDigitBox(value = code1, onValueChange = { if (it.length <= 1) code1 = it })
                OtpDigitBox(value = code2, onValueChange = { if (it.length <= 1) code2 = it })
                OtpDigitBox(value = code3, onValueChange = { if (it.length <= 1) code3 = it })
                OtpDigitBox(value = code4, onValueChange = { if (it.length <= 1) code4 = it })
            }

            Spacer(modifier = Modifier.height(40.dp))

            Button(
                onClick = {
                    val enteredCode = "$code1$code2$code3$code4"
                    if (enteredCode.length == 4) {
                        scope.launch {
                            viewModel.toggleTwoFactor(activeUser?.id ?: "", true)
                            // If user KYC is approved, go directly to Dashboard. Otherwise, force KYC setup.
                            if (activeUser?.isKycCompleted == true) {
                                onNavigateToDashboard()
                            } else {
                                onNavigateToKYC()
                            }
                        }
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = ElectricPurple),
                shape = RoundedCornerShape(12.dp),
                enabled = (code1.isNotEmpty() && code2.isNotEmpty() && code3.isNotEmpty() && code4.isNotEmpty()),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp)
            ) {
                Text(
                    text = "Confirm Identity & Unlock",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = Color.White
                )
            }

            Spacer(modifier = Modifier.height(24.dp))

            Text(
                text = "Resend security PIN in 45s",
                color = NeutralGray,
                fontSize = 13.sp,
                modifier = Modifier.clickable {
                    code1 = ""; code2 = ""; code3 = ""; code4 = ""
                }
            )
        }
    }
}

@Composable
fun OtpDigitBox(value: String, onValueChange: (String) -> Unit) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
        colors = OutlinedTextFieldDefaults.colors(
            focusedTextColor = NeutralWhite,
            unfocusedTextColor = NeutralWhite,
            focusedBorderColor = ElectricPurple,
            unfocusedBorderColor = SlateBorder,
            focusedContainerColor = SlateSurface,
            unfocusedContainerColor = SlateSurface
        ),
        textStyle = LocalTextStyle.current.copy(
            textAlign = TextAlign.Center,
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold
        ),
        modifier = Modifier
            .size(60.dp)
            .border(1.dp, if (value.isNotEmpty()) ElectricPurple else SlateBorder, RoundedCornerShape(12.dp))
    )
}

// ==========================================
// 5. KYC (IDENTITY VERIFICATION) SCREEN
// ==========================================
@Composable
fun KYCScreen(
    onNavigateToDashboard: () -> Unit,
    viewModel: GoPayViewModel
) {
    var kycStep by remember { mutableStateOf(1) } // 1 = Document selection, 2 = Scanned doc feedback, 3 = Selfie check
    var docType by remember { mutableStateOf("Passport") }
    var inputDocNum by remember { mutableStateOf("") }
    
    val scope = rememberCoroutineScope()
    val isProcessing by viewModel.isProcessing.collectAsState()
    val transactionMessage by viewModel.transactionMessage.collectAsState()

    // Animation states
    val infiniteTransition = rememberInfiniteTransition(label = "Radar Scan")
    val scanLineY = infiniteTransition.animateFloat(
        initialValue = 0.1f,
        targetValue = 0.9f,
        animationSpec = infiniteRepeatable(
            animation = tween(2000, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "Scanline"
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(DeepSlateBg)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(modifier = Modifier.height(16.dp))

            // Stage Tracker
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Identity Verification (KYC)",
                    color = NeutralWhite,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold
                )
                
                Text(
                    text = "Step $kycStep of 3",
                    color = ElectricPurple,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.height(4.dp))

            LinearProgressIndicator(
                progress = { kycStep / 3f },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(6.dp)
                    .clip(RoundedCornerShape(3.dp)),
                color = ElectricPurple,
                trackColor = SlateBorder
            )

            Spacer(modifier = Modifier.height(24.dp))

            when (kycStep) {
                1 -> {
                    // STEP 1: SELECT DOC TYPE & ID NUMBER
                    Text(
                        text = "Select Document Type",
                        color = NeutralWhite,
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    val docTypes = listOf("Passport", "National Identity Card", "Driver's License")
                    docTypes.forEach { type ->
                        Card(
                            onClick = { docType = type },
                            colors = CardDefaults.cardColors(
                                containerColor = if (docType == type) ElectricPurple.copy(alpha = 0.15f) else SlateSurface
                            ),
                            border = BorderStroke(
                                width = 1.dp,
                                color = if (docType == type) ElectricPurple else SlateBorder
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 6.dp)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(16.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = if (type == "Passport") Icons.Default.Description else Icons.Default.Badge,
                                    contentDescription = null,
                                    tint = if (docType == type) ElectricPurple else NeutralGray,
                                    modifier = Modifier.size(28.dp)
                                )
                                Spacer(modifier = Modifier.width(16.dp))
                                Text(
                                    text = type,
                                    color = NeutralWhite,
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Spacer(modifier = Modifier.weight(1f))
                                RadioButton(
                                    selected = (docType == type),
                                    onClick = { docType = type },
                                    colors = RadioButtonDefaults.colors(selectedColor = ElectricPurple)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    OutlinedTextField(
                        value = inputDocNum,
                        onValueChange = { inputDocNum = it },
                        label = { Text("Document ID Number / Registry", color = NeutralGray) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = NeutralWhite,
                            unfocusedTextColor = NeutralWhite,
                            focusedBorderColor = ElectricPurple,
                            unfocusedBorderColor = SlateBorder,
                            focusedContainerColor = SlateSurface,
                            unfocusedContainerColor = SlateSurface
                        ),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.weight(1f))

                    Button(
                        onClick = { if (inputDocNum.isNotEmpty()) kycStep = 2 },
                        colors = ButtonDefaults.buttonColors(containerColor = ElectricPurple),
                        shape = RoundedCornerShape(12.dp),
                        enabled = inputDocNum.isNotEmpty(),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(54.dp)
                    ) {
                        Text("Continue to Scan Card", fontSize = 16.sp, fontWeight = FontWeight.SemiBold, color = Color.White)
                    }
                }

                2 -> {
                    // STEP 2: SIMULATED DOC SCANNER OVERLAY
                    Text(
                        text = "Scan document front page",
                        color = NeutralWhite,
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Align your $docType inside the glowing scanner frame.",
                        color = NeutralGray,
                        fontSize = 13.sp,
                        textAlign = TextAlign.Center
                    )

                    Spacer(modifier = Modifier.height(30.dp))

                    // Scanner View Box
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(240.dp)
                            .clip(RoundedCornerShape(16.dp))
                            .background(Color.Black)
                            .border(2.dp, ElectricPurple, RoundedCornerShape(16.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        // Drawing static placeholder ID representation
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier.padding(16.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.CameraAlt,
                                contentDescription = null,
                                tint = NeutralGray,
                                modifier = Modifier.size(42.dp)
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                text = "PLACE ${docType.uppercase()} HERE",
                                color = NeutralGray,
                                fontSize = 12.sp,
                                letterSpacing = 2.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        // Laser scan overlay line
                        Canvas(modifier = Modifier.fillMaxSize()) {
                            val strokeY = size.height * scanLineY.value
                            drawLine(
                                color = ElectricPurple,
                                start = androidx.compose.ui.geometry.Offset(0f, strokeY),
                                end = androidx.compose.ui.geometry.Offset(size.width, strokeY),
                                strokeWidth = 4f,
                                pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 10f))
                            )
                        }
                    }

                    Spacer(modifier = Modifier.weight(1f))

                    Button(
                        onClick = { kycStep = 3 },
                        colors = ButtonDefaults.buttonColors(containerColor = ElectricPurple),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(54.dp)
                    ) {
                        Text("Document Captured", fontSize = 16.sp, color = Color.White)
                    }
                }

                3 -> {
                    // STEP 3: BIOMETRIC SELFIE LIVENESS
                    Text(
                        text = "Liveness Face Matching",
                        color = NeutralWhite,
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Align your face. Smile and blink when requested.",
                        color = NeutralGray,
                        fontSize = 13.sp,
                        textAlign = TextAlign.Center
                    )

                    Spacer(modifier = Modifier.height(30.dp))

                    // Circular Face Overlay Camera frame
                    Box(
                        modifier = Modifier
                            .size(240.dp)
                            .clip(CircleShape)
                            .background(Color.Black)
                            .border(3.dp, ElectricGreen, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(
                                imageVector = Icons.Default.Face,
                                contentDescription = null,
                                tint = ElectricGreen,
                                modifier = Modifier.size(70.dp)
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "SMILE NOW",
                                color = ElectricGreen,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.sp
                            )
                        }
                    }

                    Spacer(modifier = Modifier.weight(1f))

                    Button(
                        onClick = {
                            viewModel.triggerKycVerification(docType, inputDocNum) {
                                onNavigateToDashboard()
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = ElectricGreen),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(54.dp)
                    ) {
                        Text("Verify Biometric Face Profile", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    }
                }
            }
        }

        if (isProcessing) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.8f)),
                contentAlignment = Alignment.Center
            ) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = SlateSurface),
                    border = BorderStroke(1.dp, SlateBorder)
                ) {
                    Column(
                        modifier = Modifier.padding(32.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        CircularProgressIndicator(color = ElectricPurple)
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = transactionMessage ?: "Validating data...",
                            color = NeutralWhite,
                            fontSize = 14.sp
                        )
                    }
                }
            }
        }
    }
}
