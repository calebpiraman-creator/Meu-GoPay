package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Elegant Dark Theme Palette
val DeepSlateBg = Color(0xFF0E1116)      // Base background color
val SlateSurface = Color(0xFF1C1F26)     // Elevated surface / card / notice background
val SlateBorder = Color(0xFF2D333E)      // Subtle border line
val ElectricPurple = Color(0xFF2B60E2)   // Vibrant brand blue (Primary button, etc.)
val ElectricGreen = Color(0xFF24CC8C)    // Secure Green (Success/KYC)
val CoralRed = Color(0xFFFF4B55)         // Active error / Warning red
val NeutralWhite = Color(0xFFF0F2F5)     // Off-white high contrast body text
val NeutralGray = Color(0xFF8E9299)      // Soft text grey
val VisaBlue = Color(0xFF4A90E2)         // Active tab/See all/Accent Blue
val GoldVisa = Color(0xFFFFD700)         // Gold elements
val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)
val Purple40 = Color(0xFF6650a4)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)
