package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.local.entities.*
import com.example.data.network.ExchangeRateApi
import com.example.data.adapters.MockVisaIssuerAdapter
import com.example.data.adapters.MockStripePaymentAdapter
import com.example.data.repository.GoPayRepository
import com.example.data.ports.VisaSensitiveCredentials
import com.example.data.ports.StripePaymentResult
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay

class GoPayViewModel(application: Application) : AndroidViewModel(application) {
    private val db = AppDatabase.getDatabase(application)
    private val appDao = db.appDao()
    
    // Inject the Mock components
    private val cardIssuer = MockVisaIssuerAdapter()
    private val stripePayment = MockStripePaymentAdapter()
    private val exchangeRateApi = ExchangeRateApi.create()

    private val repository = GoPayRepository(appDao, cardIssuer, stripePayment, exchangeRateApi)

    // --- SHARED STATE FLOWS ---
    val activeUser = repository.activeUserFlow.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = null
    )

    val wallets = activeUser.flatMapLatest { user ->
        if (user != null) repository.getWalletsFlow(user.id) else flowOf(emptyList())
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val cards = activeUser.flatMapLatest { user ->
        if (user != null) repository.getActiveCardsFlow(user.id) else flowOf(emptyList())
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val transactions = activeUser.flatMapLatest { user ->
        if (user != null) repository.getTransactionsFlow(user.id) else flowOf(emptyList())
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val notifications = repository.getNotificationsFlow().stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val exchangeRates = repository.getLocalExchangeRatesFlow().stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    // --- UI TRANSACTION STATE FLAGGING ---
    private val _isProcessing = MutableStateFlow(false)
    val isProcessing: StateFlow<Boolean> = _isProcessing

    private val _transactionMessage = MutableStateFlow<String?>(null)
    val transactionMessage: StateFlow<String?> = _transactionMessage

    init {
        // Sync exchange rates from the Live Network API upon startup
        viewModelScope.launch {
            repository.syncExchangeRates()
        }
    }

    // --- CORE BUSINESS ACTIONS ---
    fun register(fullName: String, email: String, phone: String, country: String, onSuccess: () -> Unit) {
        viewModelScope.launch {
            _isProcessing.value = true
            _transactionMessage.value = "Creating GoPay Secure Multi-Currency Account..."
            try {
                repository.registerUser(fullName, email, phone, country)
                _transactionMessage.value = "Account setup successful!"
                delay(500)
                onSuccess()
            } catch (e: Exception) {
                _transactionMessage.value = "Registration failed: ${e.localizedMessage}"
            } finally {
                _isProcessing.value = false
            }
        }
    }

    fun logout(onSuccess: () -> Unit) {
        viewModelScope.launch {
            repository.logoutUser()
            onSuccess()
        }
    }

    fun triggerKycVerification(documentType: String, docNumber: String, onSuccess: () -> Unit) {
        viewModelScope.launch {
            val user = activeUser.value ?: return@launch
            _isProcessing.value = true
            _transactionMessage.value = "Running AI Document OCR and Face Liveness matching..."
            delay(2000) // Simulate OCR and Liveness Match processing time
            try {
                repository.completeKyc(user.id, documentType, docNumber)
                _transactionMessage.value = "KYC Verification Approved!"
                delay(800)
                onSuccess()
            } catch (e: Exception) {
                _transactionMessage.value = "Verification error: ${e.localizedMessage}"
            } finally {
                _isProcessing.value = false
            }
        }
    }

    fun fundWalletViaStripe(
        amountCents: Long,
        currency: String,
        cardNumber: String,
        expMonth: Int,
        expYear: Int,
        cvv: String,
        onSuccess: () -> Unit
    ) {
        viewModelScope.launch {
            val user = activeUser.value ?: return@launch
            _isProcessing.value = true
            _transactionMessage.value = "Authorizing transaction with Stripe Gateway..."
            try {
                val stripeResult = repository.depositFundsViaStripe(
                    userId = user.id,
                    amountCents = amountCents,
                    currency = currency,
                    cardNumber = cardNumber,
                    expMonth = expMonth,
                    expYear = expYear,
                    cvv = cvv
                )

                if (stripeResult.success) {
                    _transactionMessage.value = "Deposit approved! USD Wallet funded successfully."
                    delay(1000)
                    onSuccess()
                } else {
                    _transactionMessage.value = "Stripe Declined: ${stripeResult.errorMessage}"
                }
            } catch (e: Exception) {
                _transactionMessage.value = "Stripe Payment Error: ${e.localizedMessage}"
            } finally {
                _isProcessing.value = false
            }
        }
    }

    fun convertCurrency(
        fromCurrency: String,
        toCurrency: String,
        amountCents: Long,
        onSuccess: () -> Unit,
        onFailure: (String) -> Unit
    ) {
        viewModelScope.launch {
            val user = activeUser.value ?: return@launch
            _isProcessing.value = true
            _transactionMessage.value = "Querying live forex tables and executing exchange..."
            
            try {
                // Ensure the rates are synced
                repository.syncExchangeRates()
                
                // Get rates
                val fromRateEntity = repository.getLocalExchangeRatesFlow().firstOrNull()?.find { it.currencyCode == fromCurrency }
                val toRateEntity = repository.getLocalExchangeRatesFlow().firstOrNull()?.find { it.currencyCode == toCurrency }
                
                val fromRate = fromRateEntity?.rate ?: 1.0
                val toRate = toRateEntity?.rate ?: 1.0

                // Convert amount to USD base, then to target currency
                val usdAmount = amountCents / fromRate
                val finalExchangeRate = toRate / fromRate

                val success = repository.transferBetweenWallets(
                    userId = user.id,
                    fromCurrency = fromCurrency,
                    toCurrency = toCurrency,
                    amountCents = amountCents,
                    exchangeRate = finalExchangeRate
                )

                if (success) {
                    _transactionMessage.value = "Currency exchanged successfully!"
                    delay(1000)
                    onSuccess()
                } else {
                    onFailure("Insufficient balance in your $fromCurrency wallet.")
                }
            } catch (e: Exception) {
                onFailure("Conversion failed: ${e.localizedMessage}")
            } finally {
                _isProcessing.value = false
            }
        }
    }

    fun issueVirtualCard(
        cardholderName: String,
        maxLimitCents: Long,
        cardType: String,
        cardColor: Int,
        onSuccess: () -> Unit
    ) {
        viewModelScope.launch {
            val user = activeUser.value ?: return@launch
            _isProcessing.value = true
            _transactionMessage.value = "Contacting Visa Card Issuing Port..."
            try {
                repository.createVisaCard(
                    userId = user.id,
                    cardholderName = cardholderName,
                    maxLimitCents = maxLimitCents,
                    cardType = cardType,
                    cardColor = cardColor
                )
                _transactionMessage.value = "Visa Virtual Prepaid Card active!"
                delay(1000)
                onSuccess()
            } catch (e: Exception) {
                _transactionMessage.value = "Visa Issuance Failed: ${e.localizedMessage}"
            } finally {
                _isProcessing.value = false
            }
        }
    }

    fun toggleCardFreeze(cardId: String) {
        viewModelScope.launch {
            _isProcessing.value = true
            _transactionMessage.value = "Securing card credentials..."
            delay(500)
            try {
                repository.toggleCardFreeze(cardId)
            } finally {
                _isProcessing.value = false
            }
        }
    }

    fun terminateCard(cardId: String) {
        viewModelScope.launch {
            _isProcessing.value = true
            _transactionMessage.value = "Terminating virtual card in HSM records..."
            delay(500)
            try {
                repository.terminateCard(cardId)
            } finally {
                _isProcessing.value = false
            }
        }
    }

    fun updateCardLimit(cardId: String, limitCents: Long) {
        viewModelScope.launch {
            repository.updateCardLimit(cardId, limitCents)
        }
    }

    suspend fun revealCardDetails(cardToken: String): VisaSensitiveCredentials {
        return repository.getVisaCredentials(cardToken)
    }

    fun simulateMerchantPurchase(
        cardToken: String,
        amountCents: Long,
        merchantName: String,
        onComplete: (Boolean, String) -> Unit
    ) {
        viewModelScope.launch {
            val user = activeUser.value ?: return@launch
            _isProcessing.value = true
            _transactionMessage.value = "Authorizing transaction at Visa POS terminal..."
            delay(1200)
            try {
                val result = repository.simulateVisaPurchase(user.id, cardToken, amountCents, merchantName)
                onComplete(result.success, result.message)
            } catch (e: Exception) {
                onComplete(false, "System POS failure: ${e.localizedMessage}")
            } finally {
                _isProcessing.value = false
            }
        }
    }

    fun markNotificationAsRead(id: String) {
        viewModelScope.launch {
            repository.markNotificationAsRead(id)
        }
    }

    fun deleteNotification(id: String) {
        viewModelScope.launch {
            repository.clearNotification(id)
        }
    }

    fun syncExchangeRates() {
        viewModelScope.launch {
            repository.syncExchangeRates()
        }
    }

    fun toggleTwoFactor(userId: String, enabled: Boolean) {
        viewModelScope.launch {
            repository.enableTwoFactor(userId, enabled)
        }
    }

    fun clearMessage() {
        _transactionMessage.value = null
    }
}
