package com.example.data.repository

import com.example.data.local.dao.AppDao
import com.example.data.local.entities.*
import com.example.data.network.ExchangeRateApi
import com.example.data.ports.CardIssuerPort
import com.example.data.ports.StripePaymentPort
import com.example.data.ports.StripePaymentResult
import com.example.data.ports.VisaSensitiveCredentials
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.withContext
import java.util.UUID

class GoPayRepository(
    private val appDao: AppDao,
    private val cardIssuer: CardIssuerPort,
    private val stripePayment: StripePaymentPort,
    private val exchangeRateApi: ExchangeRateApi
) {
    // --- AUTHENTICATION & KYC ---
    val activeUserFlow: Flow<UserEntity?> = appDao.getActiveUser()

    suspend fun registerUser(
        fullName: String,
        email: String,
        phone: String,
        country: String
    ): UserEntity = withContext(Dispatchers.IO) {
        val userId = UUID.randomUUID().toString()
        val user = UserEntity(
            id = userId,
            fullName = fullName,
            email = email,
            phone = phone,
            country = country,
            isKycCompleted = false,
            kycStatus = "NOT_STARTED",
            isTwoFactorEnabled = false,
            isLoggedIn = true
        )
        appDao.logoutAllUsers()
        appDao.insertUser(user)

        // Initialize multi-currency wallets for this user in USD, EUR, GBP, MZN, ZAR, BRL, AOA, KES, NGN
        val currencies = listOf("USD", "EUR", "GBP", "MZN", "ZAR", "BRL", "AOA", "KES", "NGN")
        currencies.forEach { currency ->
            // Initialize with $100.00 USD for testing/demo ease, other currencies start at 0
            val initialBalance = if (currency == "USD") 10000L else 0L
            appDao.insertWallet(
                WalletEntity(
                    id = UUID.randomUUID().toString(),
                    userId = userId,
                    currency = currency,
                    balanceCents = initialBalance
                )
            )
        }

        // Add a friendly welcome notification
        appDao.insertNotification(
            NotificationEntity(
                id = UUID.randomUUID().toString(),
                title = "Welcome to GoPay!",
                body = "Your global Visa virtual prepaid platform is ready. Complete your KYC to unlock unlimited Visa cards.",
                timestamp = System.currentTimeMillis(),
                isRead = false,
                type = "SYSTEM"
            )
        )

        user
    }

    suspend fun loginUser(email: String): Boolean = withContext(Dispatchers.IO) {
        // Simple mock login for demo - finds any registered user or returns false
        // Real-world would call auth server. Since it's client-side, we log them in.
        val activeUser = appDao.getActiveUser().firstOrNull()
        if (activeUser != null) {
            appDao.insertUser(activeUser.copy(isLoggedIn = true))
            return@withContext true
        }
        return@withContext false
    }

    suspend fun logoutUser() = withContext(Dispatchers.IO) {
        appDao.logoutAllUsers()
    }

    suspend fun enableTwoFactor(userId: String, enabled: Boolean) = withContext(Dispatchers.IO) {
        val user = appDao.getUserById(userId)
        if (user != null) {
            appDao.insertUser(user.copy(isTwoFactorEnabled = enabled))
        }
    }

    suspend fun completeKyc(userId: String, documentType: String, docNumber: String) = withContext(Dispatchers.IO) {
        val user = appDao.getUserById(userId)
        if (user != null) {
            val updatedUser = user.copy(
                isKycCompleted = true,
                kycStatus = "APPROVED"
            )
            appDao.insertUser(updatedUser)

            appDao.insertNotification(
                NotificationEntity(
                    id = UUID.randomUUID().toString(),
                    title = "KYC Verification Approved",
                    body = "Your $documentType verification ($docNumber) was approved instantly. You can now issue Visa Virtual Cards.",
                    timestamp = System.currentTimeMillis(),
                    isRead = false,
                    type = "SECURITY"
                )
            )
        }
    }

    // --- WALLET & TRANSFERS ---
    fun getWalletsFlow(userId: String): Flow<List<WalletEntity>> = appDao.getWalletsByUserId(userId)

    fun getTransactionsFlow(userId: String): Flow<List<TransactionEntity>> = appDao.getTransactionsFlow(userId)

    suspend fun depositFundsViaStripe(
        userId: String,
        amountCents: Long,
        currency: String,
        cardNumber: String,
        expMonth: Int,
        expYear: Int,
        cvv: String
    ): StripePaymentResult = withContext(Dispatchers.IO) {
        val paymentResult = stripePayment.processDeposit(
            userId = userId,
            amountCents = amountCents,
            currency = currency,
            cardNumber = cardNumber,
            expMonth = expMonth,
            expYear = expYear,
            cvv = cvv
        )

        if (paymentResult.success) {
            // Update the local database wallet
            appDao.creditWallet(userId, currency, amountCents)

            // Insert into local append-only ledger
            appDao.insertTransaction(
                TransactionEntity(
                    id = UUID.randomUUID().toString(),
                    userId = userId,
                    cardToken = null,
                    type = "DEPOSIT",
                    amountCents = amountCents,
                    currency = currency,
                    description = "Wallet Funded via Stripe (${paymentResult.brand} *${cardNumber.takeLast(4)})",
                    timestamp = System.currentTimeMillis(),
                    status = "APPROVED",
                    merchantName = "GoPay TopUp"
                )
            )

            appDao.insertNotification(
                NotificationEntity(
                    id = UUID.randomUUID().toString(),
                    title = "Funds Deposited Successfully",
                    body = "Added $${String.format("%.2f", amountCents / 100.0)} $currency to your account.",
                    timestamp = System.currentTimeMillis(),
                    isRead = false,
                    type = "TRANSACTION"
                )
            )
        }

        paymentResult
    }

    suspend fun transferBetweenWallets(
        userId: String,
        fromCurrency: String,
        toCurrency: String,
        amountCents: Long,
        exchangeRate: Double
    ): Boolean = withContext(Dispatchers.IO) {
        val fromWallet = appDao.getWalletByCurrency(userId, fromCurrency) ?: return@withContext false
        if (fromWallet.balanceCents < amountCents) return@withContext false

        // Calculate converted amount
        val convertedAmountCents = (amountCents * exchangeRate).toLong()

        // Deduct from sender wallet
        appDao.updateWallet(fromWallet.copy(balanceCents = fromWallet.balanceCents - amountCents))

        // Credit to destination wallet
        val toWallet = appDao.getWalletByCurrency(userId, toCurrency)
        if (toWallet != null) {
            appDao.updateWallet(toWallet.copy(balanceCents = toWallet.balanceCents + convertedAmountCents))
        } else {
            appDao.insertWallet(
                WalletEntity(
                    id = UUID.randomUUID().toString(),
                    userId = userId,
                    currency = toCurrency,
                    balanceCents = convertedAmountCents
                )
            )
        }

        // Log transaction logs
        val txId = UUID.randomUUID().toString()
        appDao.insertTransaction(
            TransactionEntity(
                id = txId,
                userId = userId,
                cardToken = null,
                type = "TRANSFER",
                amountCents = -amountCents,
                currency = fromCurrency,
                description = "Currency Exchange: Exchanged $fromCurrency to $toCurrency",
                timestamp = System.currentTimeMillis(),
                status = "APPROVED",
                merchantName = "GoPay Exchange"
            )
        )

        appDao.insertTransaction(
            TransactionEntity(
                id = UUID.randomUUID().toString(),
                userId = userId,
                cardToken = null,
                type = "TRANSFER",
                amountCents = convertedAmountCents,
                currency = toCurrency,
                description = "Currency Exchange: Received from $fromCurrency",
                timestamp = System.currentTimeMillis(),
                status = "APPROVED",
                merchantName = "GoPay Exchange"
            )
        )

        appDao.insertNotification(
            NotificationEntity(
                id = UUID.randomUUID().toString(),
                title = "Currency Converted",
                body = "Exchanged $fromCurrency $${String.format("%.2f", amountCents / 100.0)} to $toCurrency $${String.format("%.2f", convertedAmountCents / 100.0)}.",
                timestamp = System.currentTimeMillis(),
                isRead = false,
                type = "TRANSACTION"
            )
        )

        true
    }

    // --- VISA VIRTUAL CARDS ---
    fun getActiveCardsFlow(userId: String): Flow<List<CardEntity>> = appDao.getActiveCardsFlow(userId)

    suspend fun createVisaCard(
        userId: String,
        cardholderName: String,
        maxLimitCents: Long,
        cardType: String,
        cardColor: Int
    ): CardEntity = withContext(Dispatchers.IO) {
        val newCard = cardIssuer.issueCard(userId, cardholderName, maxLimitCents, cardType, cardColor)
        appDao.insertCard(newCard)

        appDao.insertNotification(
            NotificationEntity(
                id = UUID.randomUUID().toString(),
                title = "New Visa Card Issued",
                body = "Your Visa Virtual Prepaid Card ending in *${newCard.lastFour} is active.",
                timestamp = System.currentTimeMillis(),
                isRead = false,
                type = "SYSTEM"
            )
        )

        newCard
    }

    suspend fun getVisaCredentials(cardToken: String): VisaSensitiveCredentials = withContext(Dispatchers.IO) {
        cardIssuer.getSensitiveCredentials(cardToken)
    }

    suspend fun toggleCardFreeze(cardId: String): String = withContext(Dispatchers.IO) {
        val card = appDao.getCardById(cardId) ?: return@withContext "NOT_FOUND"
        val newStatus = if (card.status == "ACTIVE") "FROZEN" else "ACTIVE"
        appDao.updateCardStatus(cardId, newStatus)

        appDao.insertNotification(
            NotificationEntity(
                id = UUID.randomUUID().toString(),
                title = if (newStatus == "FROZEN") "Card Frozen" else "Card Unfrozen",
                body = "Visa Virtual Card ending in *${card.lastFour} is now ${newStatus.lowercase()}.",
                timestamp = System.currentTimeMillis(),
                isRead = false,
                type = "SECURITY"
            )
        )

        newStatus
    }

    suspend fun terminateCard(cardId: String) = withContext(Dispatchers.IO) {
        val card = appDao.getCardById(cardId)
        if (card != null) {
            appDao.updateCardStatus(cardId, "TERMINATED")
            appDao.insertNotification(
                NotificationEntity(
                    id = UUID.randomUUID().toString(),
                    title = "Card Terminated",
                    body = "Your Visa card ending in *${card.lastFour} was permanently closed.",
                    timestamp = System.currentTimeMillis(),
                    isRead = false,
                    type = "SECURITY"
                )
            )
        }
    }

    suspend fun updateCardLimit(cardId: String, limitCents: Long) = withContext(Dispatchers.IO) {
        val card = appDao.getCardById(cardId)
        if (card != null) {
            appDao.insertCard(card.copy(maxLimitCents = limitCents))
        }
    }

    suspend fun simulateVisaPurchase(
        userId: String,
        cardToken: String,
        amountCents: Long,
        merchantName: String
    ): PurchaseResult = withContext(Dispatchers.IO) {
        val card = appDao.getCardByToken(cardToken) ?: return@withContext PurchaseResult(false, "Card not found.", null)
        
        if (card.status != "ACTIVE") {
            return@withContext PurchaseResult(false, "Visa Card ending in *${card.lastFour} is currently frozen.", null)
        }

        if (amountCents > card.maxLimitCents) {
            return@withContext PurchaseResult(false, "Declined: Amount exceeds card limit.", null)
        }

        val usdWallet = appDao.getWalletByCurrency(userId, "USD") ?: return@withContext PurchaseResult(false, "No active USD wallet found.", null)
        if (usdWallet.balanceCents < amountCents) {
            return@withContext PurchaseResult(false, "Declined: Insufficient funds in primary wallet.", null)
        }

        // Deduct balance
        appDao.updateWallet(usdWallet.copy(balanceCents = usdWallet.balanceCents - amountCents))

        // Create transaction history
        val transaction = TransactionEntity(
            id = UUID.randomUUID().toString(),
            userId = userId,
            cardToken = cardToken,
            type = "PURCHASE",
            amountCents = -amountCents,
            currency = "USD",
            description = "Visa purchase at $merchantName",
            timestamp = System.currentTimeMillis(),
            status = "APPROVED",
            merchantName = merchantName
        )
        appDao.insertTransaction(transaction)

        // If disposable, terminate it immediately!
        if (card.cardType == "DISPOSABLE") {
            appDao.updateCardStatus(card.id, "TERMINATED")
            appDao.insertNotification(
                NotificationEntity(
                    id = UUID.randomUUID().toString(),
                    title = "Disposable Card Self-Destructed",
                    body = "Visa Disposable card ending in *${card.lastFour} was permanently terminated after its single transaction, safeguarding your security.",
                    timestamp = System.currentTimeMillis(),
                    isRead = false,
                    type = "SECURITY"
                )
            )
        } else {
            appDao.insertNotification(
                NotificationEntity(
                    id = UUID.randomUUID().toString(),
                    title = "Card Purchase Approved",
                    body = "Spent $${String.format("%.2f", amountCents / 100.0)} USD at $merchantName with Visa ending in *${card.lastFour}.",
                    timestamp = System.currentTimeMillis(),
                    isRead = false,
                    type = "TRANSACTION"
                )
            )
        }

        PurchaseResult(true, "Purchase approved successfully.", transaction)
    }

    // --- NOTIFICATIONS ---
    fun getNotificationsFlow(): Flow<List<NotificationEntity>> = appDao.getNotificationsFlow()

    suspend fun markNotificationAsRead(id: String) = withContext(Dispatchers.IO) {
        appDao.markAsRead(id)
    }

    suspend fun clearNotification(id: String) = withContext(Dispatchers.IO) {
        appDao.deleteNotification(id)
    }

    // --- LIVE EXCHANGE RATES ---
    fun getLocalExchangeRatesFlow(): Flow<List<ExchangeRateEntity>> = appDao.getExchangeRatesFlow()

    suspend fun syncExchangeRates(): Boolean = withContext(Dispatchers.IO) {
        try {
            val response = exchangeRateApi.getRates()
            if (response.result == "success") {
                val entities = response.rates.map { (currencyCode, rate) ->
                    ExchangeRateEntity(
                        currencyCode = currencyCode,
                        rate = rate,
                        timestamp = System.currentTimeMillis()
                    )
                }
                appDao.insertExchangeRates(entities)
                return@withContext true
            }
            false
        } catch (e: Exception) {
            e.printStackTrace()
            // Fallback to static values if offline
            val offlineRates = mapOf(
                "USD" to 1.0,
                "EUR" to 0.92,
                "GBP" to 0.78,
                "MZN" to 63.8,
                "ZAR" to 18.25,
                "BRL" to 5.42,
                "AOA" to 825.0,
                "KES" to 129.0,
                "NGN" to 1510.0
            )
            val entities = offlineRates.map { (currencyCode, rate) ->
                ExchangeRateEntity(
                    currencyCode = currencyCode,
                    rate = rate,
                    timestamp = System.currentTimeMillis()
                )
            }
            appDao.insertExchangeRates(entities)
            true
        }
    }
}

data class PurchaseResult(
    val success: Boolean,
    val message: String,
    val transaction: TransactionEntity?
)
