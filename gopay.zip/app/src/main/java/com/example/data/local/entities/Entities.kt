package com.example.data.local.entities

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "users")
data class UserEntity(
    @PrimaryKey val id: String,
    val fullName: String,
    val email: String,
    val phone: String,
    val country: String,
    val isKycCompleted: Boolean,
    val kycStatus: String, // "PENDING", "APPROVED", "REJECTED", "NOT_STARTED"
    val isTwoFactorEnabled: Boolean,
    val isLoggedIn: Boolean
)

@Entity(tableName = "wallets")
data class WalletEntity(
    @PrimaryKey val id: String,
    val userId: String,
    val currency: String, // "USD", "EUR", "GBP", "MZN", "ZAR", "BRL", "AOA", "KES", "NGN"
    val balanceCents: Long // Stored in cents for double-entry arithmetic precision
)

@Entity(tableName = "cards")
data class CardEntity(
    @PrimaryKey val id: String,
    val userId: String,
    val cardToken: String,
    val lastFour: String,
    val brand: String, // "VISA"
    val cardholderName: String,
    val expMonth: Int,
    val expYear: Int,
    val status: String, // "ACTIVE", "FROZEN", "TERMINATED"
    val maxLimitCents: Long,
    val cardType: String, // "STANDARD", "DISPOSABLE"
    val cardColor: Int // Color index or Hex Int
)

@Entity(tableName = "transactions")
data class TransactionEntity(
    @PrimaryKey val id: String,
    val userId: String,
    val cardToken: String?,
    val type: String, // "DEPOSIT", "PURCHASE", "TRANSFER", "REFUND"
    val amountCents: Long, // Negative for purchases/transfers, positive for deposits/refunds
    val currency: String, // Usually "USD"
    val description: String,
    val timestamp: Long,
    val status: String, // "APPROVED", "DECLINED", "PENDING"
    val merchantName: String?
)

@Entity(tableName = "exchange_rates")
data class ExchangeRateEntity(
    @PrimaryKey val currencyCode: String, // "EUR", "GBP", "MZN", etc.
    val rate: Double, // Value relative to 1 USD
    val timestamp: Long
)

@Entity(tableName = "notifications")
data class NotificationEntity(
    @PrimaryKey val id: String,
    val title: String,
    val body: String,
    val timestamp: Long,
    val isRead: Boolean,
    val type: String // "SECURITY", "TRANSACTION", "SYSTEM"
)
