package com.example.data.ports

import com.example.data.local.entities.CardEntity
import java.util.UUID

// Port definitions for decoupled hardware, third-party, and payment APIs

interface CardIssuerPort {
    /**
     * Issue a new virtual Visa card with the specified cardholder, limits, and color theme.
     * Generates a secure card token (simulating Visa tokenization) instead of returning a raw PAN.
     */
    suspend fun issueCard(
        userId: String,
        cardholderName: String,
        maxLimitCents: Long,
        cardType: String, // "STANDARD" or "DISPOSABLE"
        cardColor: Int
    ): CardEntity

    /**
     * Secures and fetches the sensitive, ephemeral credentials (PAN, CVV, Exp) for display.
     * In compliance with PCI DSS, these are never persisted locally, only queried on-demand with 2FA/Auth.
     */
    suspend fun getSensitiveCredentials(
        cardToken: String
    ): VisaSensitiveCredentials
}

data class VisaSensitiveCredentials(
    val pan: String,
    val cvv: String,
    val expMonth: Int,
    val expYear: Int
)

interface StripePaymentPort {
    /**
     * Process a direct payment via Stripe to fund a multi-currency wallet.
     * Compliant with banking-grade security, handling tokenization and Stripe processing.
     */
    suspend fun processDeposit(
        userId: String,
        amountCents: Long,
        currency: String,
        cardNumber: String,
        expMonth: Int,
        expYear: Int,
        cvv: String
    ): StripePaymentResult
}

data class StripePaymentResult(
    val success: Boolean,
    val transactionId: String,
    val errorMessage: String?,
    val brand: String // "VISA", "MASTERCARD", "AMEX"
)
