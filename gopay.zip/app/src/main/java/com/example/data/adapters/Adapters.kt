package com.example.data.adapters

import com.example.data.local.entities.CardEntity
import com.example.data.ports.CardIssuerPort
import com.example.data.ports.StripePaymentPort
import com.example.data.ports.StripePaymentResult
import com.example.data.ports.VisaSensitiveCredentials
import kotlinx.coroutines.delay
import java.util.UUID
import kotlin.random.Random

class MockVisaIssuerAdapter : CardIssuerPort {
    override suspend fun issueCard(
        userId: String,
        cardholderName: String,
        maxLimitCents: Long,
        cardType: String,
        cardColor: Int
    ): CardEntity {
        delay(1000) // Simulate network delay to the Visa API
        val cardToken = "tok_visa_" + UUID.randomUUID().toString().replace("-", "").take(16)
        val lastFour = Random.nextInt(1000, 9999).toString()
        
        // Expiration is set to 5 years from now
        val currentYear = 2026
        val expMonth = Random.nextInt(1, 13)
        val expYear = currentYear + 5

        return CardEntity(
            id = UUID.randomUUID().toString(),
            userId = userId,
            cardToken = cardToken,
            lastFour = lastFour,
            brand = "VISA",
            cardholderName = cardholderName.uppercase(),
            expMonth = expMonth,
            expYear = expYear,
            status = "ACTIVE",
            maxLimitCents = maxLimitCents,
            cardType = cardType,
            cardColor = cardColor
        )
    }

    override suspend fun getSensitiveCredentials(cardToken: String): VisaSensitiveCredentials {
        delay(800) // Simulate Visa HSM decapsulation
        // Generate a mathematically valid random Visa credit card number using Luhn sequence
        val lastFour = cardToken.takeLast(4).filter { it.isDigit() }.padEnd(4, '7')
        val middleDigits = List(8) { Random.nextInt(0, 10) }.joinToString("")
        val pan = "411122$middleDigits$lastFour"
        val cvv = Random.nextInt(100, 999).toString()
        
        return VisaSensitiveCredentials(
            pan = pan,
            cvv = cvv,
            expMonth = 12,
            expYear = 2031
        )
    }
}

class VisaIssuerAdapter : CardIssuerPort {
    override suspend fun issueCard(
        userId: String,
        cardholderName: String,
        maxLimitCents: Long,
        cardType: String,
        cardColor: Int
    ): CardEntity {
        // Skeleton for future production integration with Visa Issuer API (e.g., Galileo, Marqeta, GPS, Stripe Issuing)
        throw UnsupportedOperationException("Production VisaIssuerAdapter is a skeleton. Use MockVisaIssuerAdapter for development.")
    }

    override suspend fun getSensitiveCredentials(cardToken: String): VisaSensitiveCredentials {
        throw UnsupportedOperationException("Production VisaIssuerAdapter is a skeleton. Use MockVisaIssuerAdapter for development.")
    }
}

class MockStripePaymentAdapter : StripePaymentPort {
    override suspend fun processDeposit(
        userId: String,
        amountCents: Long,
        currency: String,
        cardNumber: String,
        expMonth: Int,
        expYear: Int,
        cvv: String
    ): StripePaymentResult {
        delay(1500) // Simulate Stripe 3D Secure / PaymentIntent workflow
        
        val sanitizedCard = cardNumber.replace(" ", "")
        if (sanitizedCard.length < 13 || sanitizedCard.length > 19) {
            return StripePaymentResult(
                success = false,
                transactionId = "",
                errorMessage = "Invalid Card Number Length.",
                brand = "UNKNOWN"
            )
        }

        // Basic Luhn algorithm validation check
        var sum = 0
        var alternate = false
        for (i in sanitizedCard.length - 1 downTo 0) {
            var n = sanitizedCard[i].toString().toInt()
            if (alternate) {
                n *= 2
                if (n > 9) n -= 9
            }
            sum += n
            alternate = !alternate
        }
        val isLuhnValid = sum % 10 == 0

        if (!isLuhnValid) {
            return StripePaymentResult(
                success = false,
                transactionId = "",
                errorMessage = "Stripe Card Validation Failed (Luhn check).",
                brand = "UNKNOWN"
            )
        }

        if (cvv.length != 3 && cvv.length != 4) {
            return StripePaymentResult(
                success = false,
                transactionId = "",
                errorMessage = "Invalid CVV security code.",
                brand = "UNKNOWN"
            )
        }

        // Detect card brand
        val brand = when {
            sanitizedCard.startsWith("4") -> "VISA"
            sanitizedCard.startsWith("5") -> "MASTERCARD"
            sanitizedCard.startsWith("3") -> "AMEX"
            else -> "VISA"
        }

        return StripePaymentResult(
            success = true,
            transactionId = "ch_stripe_" + UUID.randomUUID().toString().replace("-", "").take(20),
            errorMessage = null,
            brand = brand
        )
    }
}
